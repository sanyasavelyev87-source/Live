"""Generate portable, non-executable BPMN 2.0 collaboration models with DI."""
from pathlib import Path
from lxml import etree as E
import json

ROOT=Path(__file__).resolve().parent
NS={'bpmn':'http://www.omg.org/spec/BPMN/20100524/MODEL','bpmndi':'http://www.omg.org/spec/BPMN/20100524/DI','dc':'http://www.omg.org/spec/DD/20100524/DC','di':'http://www.omg.org/spec/DD/20100524/DI','xsi':'http://www.w3.org/2001/XMLSchema-instance'}
def el(parent,tag,**attrs):return E.SubElement(parent,'{'+NS[tag.split(':')[0]]+'}'+tag.split(':')[1],**{k:str(v) for k,v in attrs.items()})

class Model:
    def __init__(self,id,title,purpose,refs,lanes=('Пользователь · действие и выбор','Приложение LivCi · экран и контекст','LivCi · сервер, данные и права')):
        self.id=id;self.title=title;self.purpose=purpose;self.refs=refs;self.pools=[{'id':'main','name':title,'lanes':list(lanes),'blackbox':False}];self.nodes=[];self.edges=[]
    def pool(self,id,name,lanes=(),blackbox=False):self.pools.append({'id':id,'name':name,'lanes':list(lanes),'blackbox':blackbox});return self
    def n(self,id,name,col,lane=0,type='userTask',track=0,pool='main',**kw):self.nodes.append(dict(id=id,name=name,col=col,lane=lane,type=type,track=track,pool=pool,**kw));return id
    def f(self,source,target,name='',**kw):self.edges.append(dict(source=source,target=target,name=name,**kw));return self
    def chain(self,*ids):
        for a,b in zip(ids,ids[1:]):self.f(a,b)
        return self


def write_model(m):
    pref=m.id+'_';qid=lambda x:pref+x
    doc=E.Element('{'+NS['bpmn']+'}definitions',nsmap=NS,id=qid('Definitions'),targetNamespace='urn:livci:personal-journeys:2026-10-16',exporter='LivCi personal journeys specification',exporterVersion='1.0')
    node_ids={x['id'] for x in m.nodes};pool_ids={p['id'] for p in m.pools};positions={};pool_rect={};lane_rect={};y=60;maxcol=max(n['col'] for n in m.nodes);width=220*(maxcol+1)+120
    for p in m.pools:
        if p['blackbox']:height=95
        else:
            height=0
            for index,lane in enumerate(p['lanes']):
                maxtrack=max((n['track'] for n in m.nodes if n['pool']==p['id'] and n['lane']==index),default=0)
                h=(maxtrack+1)*160+35;lane_rect[(p['id'],index)]=(90,y+height,width-30,h);height+=h
        pool_rect[p['id']]=(60,y,width,height);y+=height+105
    for n in m.nodes:
        lx,ly,lw,lh=lane_rect[(n['pool'],n['lane'])];typ=n['type'];w,h=(38,38) if typ.endswith('Event') or n.get('compact') else (54,54) if typ.endswith('Gateway') else (158,86)
        x=160+n['col']*220;ny=ly+64+n['track']*160
        if typ=='boundaryEvent':
            host=next(x for x in m.nodes if x['id']==n['attached']);x=160+host['col']*220+120;ny=ly+64+host['track']*160+67
        positions[n['id']]=(x,ny,w,h)
    for p in m.pools:
        if p['blackbox']:continue
        process=el(doc,'bpmn:process',id=qid('Process_'+p['id']),isExecutable='false')
        description=el(process,'bpmn:documentation');description.text=m.purpose+' Источники DOCX: '+', '.join(getattr(m,'sources',[]))+'. Референсы: '+', '.join(m.refs)+'. Рабочая модель пути, не исполнение backend.'
        ls=el(process,'bpmn:laneSet',id=qid('LaneSet_'+p['id']))
        for index,name in enumerate(p['lanes']):
            lane=el(ls,'bpmn:lane',id=qid('Lane_'+p['id']+'_'+str(index)),name=name)
            for n in m.nodes:
                if n['pool']==p['id'] and n['lane']==index:el(lane,'bpmn:flowNodeRef').text=qid(n['id'])
        for n in m.nodes:
            if n['pool']!=p['id']:continue
            attrs={'id':qid(n['id']),'name':n['name']}
            if n['type']=='boundaryEvent':attrs.update(attachedToRef=qid(n['attached']),cancelActivity='true')
            elem=el(process,'bpmn:'+n['type'],**attrs)
            if n.get('sources') or n.get('certainty') or n.get('note'):
                annotation=el(elem,'bpmn:documentation');annotation.text='Источники: '+', '.join(n.get('sources',[]))+'. Уровень: '+n.get('certainty','подтверждено/следствие')+'. '+n.get('note','')
            if n.get('called'):
                d=el(elem,'bpmn:documentation');d.text='Детализация: '+n['called']+'.bpmn; внешний документ. calledElement не задан, потому что пакет неисполняемый.'
            for direction,key in [('incoming','target'),('outgoing','source')]:
                for flowIndex,flow in enumerate(m.edges):
                    if flow.get('kind')!='message' and flow[key]==n['id']:el(elem,'bpmn:'+direction).text=qid('Flow_'+str(flowIndex))
            if n.get('timer'):
                td=el(elem,'bpmn:timerEventDefinition',id=qid(n['id']+'_Timer'));t=el(td,'bpmn:'+n.get('timerKind','timeDuration'));t.text=n['timer']
            elif n.get('message'):el(elem,'bpmn:messageEventDefinition',id=qid(n['id']+'_Message'))
        for i,f in enumerate(m.edges):
            if f.get('kind')=='message':continue
            a=next(n for n in m.nodes if n['id']==f['source']);b=next(n for n in m.nodes if n['id']==f['target']);assert a['pool']==b['pool'],(m.id,f)
            if a['pool']!=p['id']:continue
            attrs=dict(id=qid('Flow_'+str(i)),sourceRef=qid(f['source']),targetRef=qid(f['target']))
            if f['name']:attrs['name']=f['name']
            flow=el(process,'bpmn:sequenceFlow',**attrs)
            if f.get('condition'):el(flow,'bpmn:conditionExpression').text=f['condition']
    col=el(doc,'bpmn:collaboration',id=qid('Collaboration'))
    for p in m.pools:
        attrs=dict(id=qid('Participant_'+p['id']),name=p['name'])
        if not p['blackbox']:attrs['processRef']=qid('Process_'+p['id'])
        el(col,'bpmn:participant',**attrs)
    for i,f in enumerate(m.edges):
        if f.get('kind')!='message':continue
        source=qid('Participant_'+f['source']) if f['source'] in pool_ids else qid(f['source']);target=qid('Participant_'+f['target']) if f['target'] in pool_ids else qid(f['target'])
        el(col,'bpmn:messageFlow',id=qid('Flow_'+str(i)),name=f['name'],sourceRef=source,targetRef=target)
    diagram=el(doc,'bpmndi:BPMNDiagram',id=qid('Diagram'),name=m.title);plane=el(diagram,'bpmndi:BPMNPlane',id=qid('Plane'),bpmnElement=qid('Collaboration'))
    def shape(id,rect,**attrs):
        s=el(plane,'bpmndi:BPMNShape',id=qid(id+'_di'),bpmnElement=qid(id),**attrs);x,y,w,h=rect;el(s,'dc:Bounds',x=x,y=y,width=w,height=h);return s
    for p in m.pools:
        shape('Participant_'+p['id'],pool_rect[p['id']],isHorizontal='true')
        if not p['blackbox']:
            for index in range(len(p['lanes'])):shape('Lane_'+p['id']+'_'+str(index),lane_rect[(p['id'],index)],isHorizontal='true')
    for n in m.nodes:
        attrs={'isExpanded':'false'} if n['type']=='callActivity' else {'isMarkerVisible':'true'} if n['type']=='exclusiveGateway' else {}
        s=shape(n['id'],positions[n['id']],**attrs)
        if n['name'] and (n['type'].endswith('Event') or n['type'].endswith('Gateway')):
            x,y,w,h=positions[n['id']];label=el(s,'bpmndi:BPMNLabel');el(label,'dc:Bounds',x=x-48,y=y+h+9,width=w+96,height=45)
    def box(id):return pool_rect[id] if id in pool_ids else positions[id]
    for i,f in enumerate(m.edges):
        ax,ay,aw,ah=box(f['source']);bx,by,bw,bh=box(f['target']);sx,sy=ax+aw,ay+ah/2;tx,ty=bx,by+bh/2
        if f.get('kind')=='message':
            sx,sy=ax+aw/2,ay+ah;tx,ty=bx+bw/2,by
            if sy>ty:sx,sy=ax+aw/2,ay;tx,ty=bx+bw/2,by+bh
            mid=(sy+ty)/2;points=[(sx,sy),(sx,mid),(tx,mid),(tx,ty)]
        elif abs(ay-by)<4 and bx>ax:points=[(sx,sy),(tx,ty)]
        elif abs(ax-bx)<4:
            sx=ax+aw/2;tx=bx+bw/2
            if by>ay:sy=ay+ah;ty=by
            else:sy=ay;ty=by+bh
            mid=(sy+ty)/2;points=[(sx,sy),(sx,mid),(tx,mid),(tx,ty)]
        elif bx<ax:
            sx,sy=ax+aw/2,ay;tx,ty=bx+bw/2,by;routeY=min(ay,by)-27;points=[(sx,sy),(sx,routeY),(tx,routeY),(tx,ty)]
        else:
            middle=(sx+tx)/2;points=[(sx,sy),(middle,sy),(middle,ty),(tx,ty)]
        # Route around task/event boxes rather than drawing through an intermediate activity.
        def obstructed(path):
            for (x1,y1),(x2,y2) in zip(path,path[1:]):
                for rx,ry,rw,rh in positions.values():
                    if abs(y2-y1)<.1 and ry+1<y1<ry+rh-1 and min(max(x1,x2),rx+rw-1)>max(min(x1,x2),rx+1):return True
                    if abs(x2-x1)<.1 and rx+1<x1<rx+rw-1 and min(max(y1,y2),ry+rh-1)>max(min(y1,y2),ry+1):return True
            return False
        if obstructed(points):
            candidates=[]
            for xs in [ax+aw+5,ax+aw+25,ax-5,ax-25]:
                for xt in [bx-5,bx-25,bx+bw+5,bx+bw+25]:
                    for band in [min(ay,by)-24,max(ay+ah,by+bh)+24,min(r[1] for r in positions.values())-35]:
                        startX=ax+aw if xs>ax else ax;endX=bx if xt<bx else bx+bw
                        path=[(startX,ay+ah/2),(xs,ay+ah/2),(xs,band),(xt,band),(xt,by+bh/2),(endX,by+bh/2)]
                        if not obstructed(path):candidates.append((sum(abs(a[0]-b[0])+abs(a[1]-b[1]) for a,b in zip(path,path[1:])),path))
            if candidates:points=min(candidates,key=lambda p:p[0])[1]
        edge=el(plane,'bpmndi:BPMNEdge',id=qid('Flow_'+str(i)+'_di'),bpmnElement=qid('Flow_'+str(i)))
        clean=[]
        for point in points:
            if not clean or clean[-1]!=point:clean.append(point)
        for x,y in clean:el(edge,'di:waypoint',x=x,y=y)
        if f['name']:
            start=clean[max(0,len(clean)//2-1)];end=clean[len(clean)//2];cx=(start[0]+end[0])/2;cy=(start[1]+end[1])/2
            lab=el(edge,'bpmndi:BPMNLabel');el(lab,'dc:Bounds',x=cx-75,y=cy-27,width=150,height=36)
    target=ROOT/'models'/f'{m.id}.bpmn';target.parent.mkdir(exist_ok=True);E.ElementTree(doc).write(target,encoding='UTF-8',xml_declaration=True,pretty_print=True)
    return dict(id=m.id,title=m.title,purpose=m.purpose,references=m.refs,file='models/'+target.name,nodes=len(m.nodes),flows=len(m.edges),pools=len(m.pools))

