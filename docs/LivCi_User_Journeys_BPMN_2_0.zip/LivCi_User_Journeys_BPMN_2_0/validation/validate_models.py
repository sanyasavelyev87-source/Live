"""Validate BPMN schemas, references, graph reachability and participant boundaries."""
from pathlib import Path
from collections import defaultdict,deque
from lxml import etree as E
import json,hashlib

ROOT=Path(__file__).resolve().parents[1]
B='http://www.omg.org/spec/BPMN/20100524/MODEL'
D='http://www.omg.org/spec/BPMN/20100524/DI'
schema=E.XMLSchema(E.parse(str(ROOT/'validation/xsd/BPMN20.xsd')))
errors=[];models=[]
for path in sorted((ROOT/'models').glob('*.bpmn')):
    doc=E.parse(str(path));problems=[]
    if not schema.validate(doc):problems.append(str(schema.error_log))
    elements={n.get('id'):n for n in doc.iter() if n.get('id')}
    ids=[n.get('id') for n in doc.iter() if n.get('id')]
    if len(ids)!=len(set(ids)):problems.append('Duplicate XML ids')
    owner={};nodes={};adj=defaultdict(list);rev=defaultdict(list);outgoing=defaultdict(list)
    for proc in doc.findall('{'+B+'}process'):
        for n in proc:
            tag=E.QName(n).localname
            if tag not in ['documentation','laneSet','sequenceFlow','extensionElements'] and n.get('id'):
                owner[n.get('id')]=proc.get('id');nodes[n.get('id')]=n
    for f in doc.findall('.//{'+B+'}sequenceFlow'):
        a,b=f.get('sourceRef'),f.get('targetRef')
        if a not in nodes or b not in nodes:problems.append('Invalid flow reference '+str((a,b)));continue
        if owner[a]!=owner[b]:problems.append('Sequence flow crosses process boundary '+f.get('id'))
        adj[a].append(b);rev[b].append(a);outgoing[a].append(f)
    participants=doc.findall('.//{'+B+'}participant');proc_part={p.get('processRef'):p.get('id') for p in participants if p.get('processRef')}
    def part(id):return proc_part.get(owner[id]) if id in owner else id
    for f in doc.findall('.//{'+B+'}messageFlow'):
        a,b=f.get('sourceRef'),f.get('targetRef')
        if a not in elements or b not in elements:problems.append('Invalid message endpoints')
        elif part(a)==part(b):problems.append('Message flow inside same participant '+f.get('id'))
    starts=[id for id,n in nodes.items() if E.QName(n).localname=='startEvent'];ends=[id for id,n in nodes.items() if E.QName(n).localname=='endEvent']
    for id,n in nodes.items():
        tag=E.QName(n).localname
        if tag=='startEvent' and rev[id]:problems.append('Start has incoming sequence flow '+id)
        if tag=='endEvent' and adj[id]:problems.append('End has outgoing sequence flow '+id)
        if tag=='boundaryEvent':
            host=n.get('attachedToRef');adj[host].append(id);rev[id].append(host)
        if tag=='exclusiveGateway' and len(outgoing[id])>1 and any(not f.get('name') for f in outgoing[id]):problems.append('Unlabelled choice '+id)
        if tag.endswith('Task') and len(outgoing[id])>1:problems.append('Accidental implicit parallel task split '+id)
    def walk(seeds,graph):
        found=set(seeds);q=deque(seeds)
        while q:
            for target in graph[q.popleft()]:
                if target not in found:found.add(target);q.append(target)
        return found
    missing=set(nodes)-walk(starts,adj)
    if missing:problems.append('Unreachable from start: '+', '.join(sorted(missing)))
    stranded=set(nodes)-walk(ends,rev)
    if stranded:problems.append('No route to an outcome: '+', '.join(sorted(stranded)))
    shaped={n.get('bpmnElement') for n in doc.findall('.//{'+D+'}BPMNShape')}
    if set(nodes)-shaped:problems.append('Flow nodes missing DI shapes')
    edged={n.get('bpmnElement') for n in doc.findall('.//{'+D+'}BPMNEdge')}
    flows=doc.findall('.//{'+B+'}sequenceFlow')+doc.findall('.//{'+B+'}messageFlow')
    if {f.get('id') for f in flows}-edged:problems.append('Flows missing DI edges')
    models.append({'file':path.name,'xsdValid':schema.validate(doc),'nodes':len(nodes),'flows':len(flows),'errors':problems})
    errors.extend(path.name+': '+p for p in problems)
refs=json.loads((ROOT/'references/index.json').read_text())
for ref in refs:
    if not (ROOT/ref['path']).is_file():errors.append('Missing source '+ref['id'])
master=E.parse(str(ROOT/'LivCi_User_Journeys.bpmn'));masterValid=schema.validate(master)
if not masterValid:errors.append('Combined XML: '+str(schema.error_log))
masterIds=[n.get('id') for n in master.iter() if n.get('id')]
if len(masterIds)!=len(set(masterIds)):errors.append('Combined XML has duplicate ids')
diagrams=len(master.findall('.//{'+D+'}BPMNDiagram'))
if diagrams!=8:errors.append('Combined XML must contain8diagrams')
report={'modelCount':len(models),'models':models,'referenceCount':len(refs),'combinedXsdValid':masterValid,'combinedDiagrams':diagrams,'errors':errors,'pass':not errors and len(models)==8 and len(refs)==17}
(ROOT/'validation/structure-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print(json.dumps({'models':len(models),'nodes':sum(m['nodes'] for m in models),'flows':sum(m['flows'] for m in models),'references':len(refs),'errors':errors,'pass':report['pass']},ensure_ascii=False))
raise SystemExit(0 if report['pass'] else 1)
