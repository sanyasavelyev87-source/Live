/* Browser checks and vector artifact export. Run against a local HTTP server. */
const fs=require('fs'),path=require('path');
const {chromium}=require(process.env.PLAYWRIGHT_PATH||'playwright');
const root=path.resolve(__dirname,'..'),url=process.env.LIVCI_VIEWER_URL||'http://127.0.0.1:8124/docs/personal-journeys-bpmn/';
let browser;
const escape=x=>String(x).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
(async()=>{
 const report={models:[],errors:[],httpErrors:[],checks:[],combinedImports:[]};
 browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
 const page=await browser.newPage({viewport:{width:1680,height:1000}});
 page.on('pageerror',e=>report.errors.push(e.message));page.on('response',r=>{if(r.status()>=400)report.httpErrors.push({status:r.status(),url:r.url()})});
 await page.goto(url,{waitUntil:'networkidle'});await page.waitForSelector('body[data-ready="U01"]');
 for(const id of await page.evaluate(()=>LivciBpmn.models.map(x=>x.id))){
   const r=await page.evaluate(async id=>{const{warnings}=await LivciBpmn.open(id);return{id,warnings:warnings.map(w=>w.message),elements:LivciBpmn.viewer.get('elementRegistry').getAll().length,svg:await LivciBpmn.svg()}},id);
   fs.writeFileSync(path.join(root,'diagrams',id+'.svg'),r.svg);delete r.svg;report.models.push(r);if(r.warnings.length)report.errors.push(id+': '+r.warnings.join('; '));
 }
 await page.evaluate(()=>LivciBpmn.open('U01'));await page.locator('#canvas').screenshot({path:path.join(root,'validation','U01-preview.png')});
 await page.evaluate(()=>LivciBpmn.open('U02'));await page.locator('#canvas').screenshot({path:path.join(root,'validation','U02-preview.png')});
 await page.getByRole('button',{name:'Вкладки и клиентский путь',exact:true}).click();
 const spec=await page.locator('#spec-content').textContent();report.checks.push({name:'Specification visible and personal decisions present',pass:await page.locator('#spec-content').isVisible()&&spec.includes('Карта / Люди / Создать / Сообщества / Профиль')&&spec.includes('$80')&&spec.includes('R09')});
 await page.emulateMedia({media:'print'});await page.pdf({path:path.join(root,'LivCi_User_Journeys_Specification.pdf'),format:'A4',printBackground:true,preferCSSPageSize:true});await page.emulateMedia({media:'screen'});
 await page.getByRole('button',{name:'Референсы',exact:true}).click();await page.locator('.ref-card img').evaluateAll(imgs=>imgs.forEach(x=>x.loading='eager'));await page.waitForFunction(()=>[...document.querySelectorAll('.ref-card img')].every(x=>x.complete&&x.naturalWidth>0));
 report.checks.push({name:'17 original images load',pass:await page.locator('.ref-card').count()===17});
 await page.getByRole('button',{name:'Процессы',exact:true}).click();await page.locator('[data-model="U03"]').click();await page.waitForSelector('body[data-ready="U03"]');
 await page.locator('[data-element-id="U03_map"] > .djs-hit').dblclick();await page.waitForSelector('body[data-ready="U04"]');report.checks.push({name:'Actual double click opens subprocess',pass:true});
 const dl=page.waitForEvent('download');await page.getByRole('button',{name:'BPMN XML',exact:true}).click();report.checks.push({name:'XML download',pass:(await dl).suggestedFilename()==='U04.bpmn'});
 const svgdl=page.waitForEvent('download');await page.getByRole('button',{name:'SVG',exact:true}).click();report.checks.push({name:'SVG download',pass:(await svgdl).suggestedFilename()==='U04.svg'});
 await page.locator('#zoom-in').click();await page.locator('#fit').click();report.checks.push({name:'Zoom and fit',pass:await page.evaluate(()=>LivciBpmn.viewer.get('canvas').zoom()>0)});
 await page.setViewportSize({width:390,height:844});const dims=await page.evaluate(()=>({width:innerWidth,scroll:document.documentElement.scrollWidth}));report.checks.push({name:'Shell fits 390px',pass:dims.scroll<=dims.width+1,detail:dims});await page.setViewportSize({width:1680,height:1000});
 report.combinedImports=await page.evaluate(async()=>{const xml=await(await fetch('LivCi_User_Journeys.bpmn')).text();let rows=[];for(const m of LivciBpmn.models){const r=await LivciBpmn.viewer.importXML(xml,m.id+'_Diagram');rows.push({id:m.id,warnings:r.warnings.map(w=>w.message)})}return rows});
 if(report.combinedImports.some(x=>x.warnings.length))report.errors.push('Combined import warnings');
 const temp=process.env.LIVCI_PDF_TEMP||'/workspace/scratch/personal-diagram-pages';fs.mkdirSync(temp,{recursive:true});
 for(const m of JSON.parse(fs.readFileSync(path.join(root,'model-index.json'),'utf8'))){
   let svg=fs.readFileSync(path.join(root,'diagrams',m.id+'.svg'),'utf8');svg=svg.slice(svg.indexOf('<svg'));const width=Number(svg.match(/\bwidth="([\d.]+)"/)[1]),height=Number(svg.match(/\bheight="([\d.]+)"/)[1]);
   await page.setContent('<!doctype html><html lang="ru"><meta charset="utf-8"><style>html,body{margin:0;background:#fff;color:#142a3d;font-family:Arial}h1{font-size:23px;margin:0 0 10px}p{font-size:13px;line-height:1.5;margin:0 0 15px}.notes{font-size:11px;color:#587185;margin-top:10px}svg{display:block;margin:auto}</style><h1>'+escape(m.id+' · '+m.title)+'</h1><p>'+escape(m.purpose)+'</p>'+svg+'<p class="notes">Источники: '+m.references.join(', ')+' · LivCi · личный аккаунт · 16.10.2026 · BPMN 2.0, спецификация без исполнения сервисов.</p></html>');
   await page.pdf({path:path.join(temp,m.id+'.pdf'),width:(width+80)+'px',height:(height+400)+'px',margin:{top:'22px',bottom:'22px',left:'25px',right:'25px'},printBackground:true});
 }
 report.pass=!report.errors.length&&!report.httpErrors.length&&report.checks.every(x=>x.pass)&&report.models.length===8&&report.combinedImports.length===8;
 fs.writeFileSync(path.join(root,'validation','browser-report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));await browser.close();process.exitCode=report.pass?0:1;
})().catch(async e=>{console.error(e);await browser?.close();process.exitCode=1});
