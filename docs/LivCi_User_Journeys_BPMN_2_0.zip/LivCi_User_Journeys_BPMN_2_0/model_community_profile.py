"""Personal community and profile journeys; model construction only.

The models are descriptive BPMN. They do not execute service commands, payment,
messages or account deletion. Diagram task documentation retains the rules that
would make a single screen unreadable if every validation became a new task.
"""

from bpmn_core import Model

LANES = ("User", "Client", "Server")


def _community_model():
    m = Model(
        "U07",
        "Сообщества, события, рилсы и социальные подписки",
        (
            "Вход из P10/P09/P08, карточки карты U04 либо вложенных P01/P03 "
            "профиля U08. Один проход выполняет выбранное действие и возвращает "
            "источник с прежними вкладкой, фильтром и прокруткой. P10/P09/P08 "
            "показывают актуальные разрешённые Community/Event/Reel. "
            "P03 содержит только Community с owner_user_id текущего пользователя, "
            "максимум три; сервер атомарно проверяет лимит и capability. "
            "SocialFollow.targetCommunityId ссылается на Community; Venue связан "
            "с бизнес-Community. Follow, Membership и владение независимы. "
            "P01 Подписки показывает follows, Мои заведения — связанные Venue; "
            "Рилсы — только разрешённые Reel follow-набора. Рекомендация не Follow. "
            "UNFOLLOW убирает объект из персонального фида, не удаляет Reel, "
            "Membership, owner-роль или публичный каталог. "
            "Event отклик проверяет место атомарно, включая инициатора; полный "
            "состав/лист ожидания не изображается подтверждённым участием. "
            "Предложение места из waitlist подтверждается за 30 минут. "
            "P09 Билеты — демонстрационная кнопка: продажи билетов и платёжной "
            "интеграции этот процесс не вводит. "
            "Reel не Circle, у него нет автоматического маркера или TTL 90 минут. "
            "Удаление Community допускается после подтверждения и по согласованному "
            "lifecycle; судьба прошлых медиа/чатов открыта, каскады не придуманы. "
            "Каждое чтение/запись проверяет session/ACL/TTL/capability; показ "
            "ошибки/пустого списка не выдаёт закрытые данные. До серверного "
            "подтверждения вступление, подписка, создание или удаление не завершены."
        ),
        ["UR11", "UR10", "UR09", "UR04", "UR02"],
        lanes=LANES,
    )
    m.sources = [
        "P1083", "P1084", "P1085", "P1089", "P1090", "P1091",
        "P1095", "P1096", "P1097", "P1137", "P1138", "P1139",
        "P1143", "P1144", "P1145", "P2164", "P2193", "P2194",
        "P2195", "P2198", "P2199", "P2200", "P2203", "P2204",
        "P2205", "P2238", "P2239", "P2240", "P2243", "P2244",
        "P2245", "P2248", "P2249", "P2250", "P2251", "P2258",
        "P2422", "P2423", "P2424", "P2425", "P2426", "P2428",
        "P2439", "P2440", "T2420", "T2435",
    ]

    def n(id, name, col, lane, type="userTask", track=0, **kw):
        kw.setdefault("sources", ["P2164", "P2426"])
        kw.setdefault("certainty", "подтверждено/следствие")
        return m.n(id, name, col, lane, type=type, track=track, **kw)

    n("start", "Вход в сообщества", 0, 0, "startEvent",
      sources=["P2192", "P2197", "P2202", "P2242", "P2237"])
    n("context", "Сохранить источник и выбранное действие", 1, 1, "serviceTask",
      note="Прямые входы P01/P03/карточки не требуют предварительного посещения каталога.")
    n("access", "Проверить сессию, ACL и актуальность", 2, 2, "serviceTask",
      sources=["P2422", "P2426"])
    n("authorized", "Доступ разрешён?", 3, 2, "exclusiveGateway")
    n("route", "Какой контекст выбран?", 4, 0, "exclusiveGateway",
      sources=["T2435"])

    n("catalog", "Показать P10 / P09 / P08 и фильтры", 5, 1, "serviceTask",
      sources=["P2193", "P2198", "P2203"],
      note="Категории/табы внутри Сообществ. Карточки используют исходные ID; "
           "пустой список и ошибка отличаются. Билеты на P09 не запускают покупку.")
    n("catalog_state", "Состояние каталога и действие?", 6, 1,
      "exclusiveGateway", sources=["P2165", "P2206"],
      note="Пустой список/ошибка/скрытые объекты не требуют выбора несуществующей карточки. "
           "Повтор чтения заново проверяет доступ и не повторяет команду записи.")
    n("choose_catalog", "Выбрать объект или разрешённое действие", 7, 0,
      sources=["P2194", "P2199", "P2204"])
    n("catalog_route", "Действие каталога?", 8, 0, "exclusiveGateway")
    n("read_map", "Просмотр объекта на карте · U04", 8, 1, "callActivity",
      called="U04", sources=["P1060", "P2174", "P2422"],
      note="Из разрешённой карточки; отсутствие живого маркера не возрождает TTL. "
           "Чтение самой Community/Event/Reel остаётся в исходном контексте.")
    n("membership", "Проверить и записать Membership / заявку", 8, 2, "serviceTask",
      sources=["P1084", "P2194", "P2195", "P2423"],
      note="По типу доступа: членство либо ожидающая заявка; Follow и owner-роль не назначаются.")
    n("event", "Проверить место и записать Participation", 8, 2, "serviceTask", track=1,
      sources=["P1090", "P2199", "P2425", "T2435"],
      note="Атомарный guard вместимости с инициатором; показать принятый/ожидающий/"
           "отказанный статус. Разрешённый Event chat использует тот же chat_id. "
           "При waitlist 30 минут на подтверждение предложенного места. "
           "Событие не получает постоянный маркер; Билеты не реализуют продажу.")
    n("reel", "Выдать Reel; проверить лайк / комментарий / share", 8, 2,
      "serviceTask", track=2,
      sources=["P1096", "P1097", "P2204", "P2205"],
      note="Разрешённый просмотр/Like/комментарий; share — deep link с ACL. "
           "Авторство ведёт в ту же Community/разрешённый Profile; TTL Circle не применяется.")

    n("follow_view", "Открыть P01 или Follow из карточки", 5, 1, "serviceTask", track=1,
      sources=["P1143", "P2243", "P2423"],
      note="Подписки / Рилсы; Мои комьюнити / Мои заведения / рекомендации. "
           "Смотреть все раскрывает полный разрешённый список; рекомендации ещё не подписаны.")
    n("choose_follow", "Выбрать Follow, Unfollow или фид", 6, 0, track=1,
      sources=["P2244", "P2245"])
    n("follow_route", "Действие социальной подписки?", 7, 0, "exclusiveGateway", track=1)
    n("follow", "Создать Follow на targetCommunityId", 8, 2, "serviceTask", track=3,
      sources=["P2249", "P2423", "P2428"],
      note="Venue подписывается через связанную бизнес-Community. Бесплатное "
           "социальное действие не назначает Membership/owner и не покупает Plus.")
    n("unfollow", "Удалить только связь Follow", 9, 2, "serviceTask", track=3,
      sources=["P2245", "P2258", "P2424", "P2440"],
      note="Убрать из персонального feed; не удалить Reel, Membership, "
           "владение или запись публичного каталога.")
    n("feed", "Выдать только разрешённые Reel follow-набора", 10, 2,
      "serviceTask", track=3,
      sources=["P2244", "P2249", "P2258", "P2423"],
      note="Для неподписанной рекомендации чужие Reel не подмешиваются как follow feed.")

    n("own_view", "Открыть P03: только собственные Community", 5, 1,
      "serviceTask", track=2,
      sources=["P2238", "P2248"],
      note="owner_user_id текущего пользователя, счётчик до 3; "
           "членство в чужом сообществе не расходует лимит.")
    n("choose_own", "Выбрать создать, управлять, открыть или удалить", 6, 0,
      track=2, sources=["P2239"])
    n("own_route", "Действие собственного Community?", 7, 0,
      "exclusiveGateway", track=2)
    n("create", "Атомарно проверить < 3 и создать Community", 8, 2,
      "serviceTask", track=4,
      sources=["P2250", "P2439", "P2428"],
      note="Guard и запись в одной атомарной операции. При 3/3 "
           "четвёртая запись не создаётся, даже если кнопка на референсе активна.")
    n("create_result", "Создание подтверждено?", 9, 2, "exclusiveGateway", track=4,
      sources=["P2240", "P2250"])
    n("limit", "Показать лимит 3/3 или причину отказа", 10, 1,
      "serviceTask", track=4, sources=["P2240", "P2250"],
      note="Не предлагать скрытую покупку лимита; при технической ошибке "
           "сохранить форму и разрешить безопасный повтор из источника.")
    n("manage", "Проверить owner/capability и открыть управление", 8, 2,
      "serviceTask", track=5,
      sources=["P2239", "P2248", "P2426"],
      note="Управление только конкретным community_id; личные права не становятся бизнес-правами.")
    n("preview", "Открыть публичный вид того же community_id", 8, 1,
      "serviceTask", track=4, sources=["P2239", "P2248"],
      note="Данные ограничены текущими правами, копия Community не создаётся.")
    n("confirm_delete", "Подтвердить удаление Community", 8, 0, track=3,
      sources=["P2251", "P2424"])
    n("delete_choice", "Удаление подтверждено?", 9, 0, "exclusiveGateway", track=3)
    n("delete", "Выполнить разрешённое удаление по lifecycle", 10, 2,
      "serviceTask", track=5,
      sources=["P2251", "P2424", "P2426"],
      certainty="подтверждено; lifecycle частично открыт",
      note="Выполнять только согласованные последствия удаления. "
           "Если регламент для данных не определён, показать блокирующее уточнение; "
           "не стирать автоматически старые медиа/чаты и бизнес-объекты.")

    n("merge", "Результат выбранного действия", 11, 2, "exclusiveGateway", track=2)
    n("result", "Сервер подтвердил результат?", 12, 2, "exclusiveGateway", track=2,
      sources=["P2206", "P2241", "P2246", "P2428"])
    n("sync", "Показать статус; синхронизировать те же ID", 13, 1,
      "serviceTask", sources=["P2166", "P2427"],
      note="Ожидающая заявка не отображается уже принятым членством/участием.")
    n("error", "Показать отказ / ошибку без ложного успеха", 13, 1,
      "serviceTask", track=3,
      sources=["P2165", "P2246", "P2424", "P2428"])
    n("retry_choice", "Выбрать повтор или возврат", 14, 0, track=4)
    n("retry_route", "Повторить сохранённую команду?", 14, 1,
      "exclusiveGateway", track=3)
    n("retry", "Повторить идемпотентно с новыми ACL", 12, 2,
      "serviceTask", track=5,
      sources=["P2426", "P2428"],
      note="Сохранённый тип команды и target ID; нет дубля Follow/Participation/Community. "
           "Неподтверждённое удаление не выполняется.")
    n("restore", "Вернуть источник, вкладку и позицию", 14, 1,
      "serviceTask", sources=["P2164", "P2422"],
      note="При отказе не показывать закрытые данные; техническая ошибка "
           "создания сохраняет форму для повтора.")
    n("end", "Контекст восстановлен", 15, 0, "endEvent")

    m.chain("start", "context", "access", "authorized")
    m.f("authorized", "route", "Да")
    m.f("authorized", "error", "Нет / нет сети / скрыто")
    m.f("route", "catalog", "Каталог Community / Event / Reel")
    m.f("route", "follow_view", "P01 или Follow из карточки")
    m.f("route", "own_view", "P03: созданные мной")

    m.chain("catalog", "catalog_state")
    m.f("catalog_state", "choose_catalog", "Есть доступные объекты: выбрать")
    m.f("catalog_state", "access", "Повторить только чтение")
    m.f("catalog_state", "restore", "Пусто / ошибка / скрыто / назад")
    m.chain("choose_catalog", "catalog_route")
    m.f("catalog_route", "read_map", "Просмотр на карте")
    m.f("catalog_route", "restore", "Только чтение / назад")
    m.f("catalog_route", "membership", "Вступление / заявка")
    m.f("catalog_route", "event", "Отклик на Event")
    m.f("catalog_route", "reel", "Reel: просмотр / действие")
    m.f("read_map", "restore")
    for task in ("membership", "event", "reel"):
        m.f(task, "merge")

    m.chain("follow_view", "choose_follow", "follow_route")
    m.f("follow_route", "follow", "Подписаться")
    m.f("follow_route", "unfollow", "Отписаться")
    m.f("follow_route", "feed", "Открыть Рилсы подписок")
    m.f("follow_route", "restore", "Назад без изменения")
    for task in ("follow", "unfollow", "feed"):
        m.f(task, "merge")

    m.chain("own_view", "choose_own", "own_route")
    m.f("own_route", "create", "Создать")
    m.f("own_route", "manage", "Управлять")
    m.f("own_route", "preview", "Открыть")
    m.f("own_route", "confirm_delete", "Удалить через ⋯")
    m.f("own_route", "restore", "Назад без изменения")
    m.chain("create", "create_result")
    m.f("create_result", "merge", "Да: атомарный guard прошёл")
    m.f("create_result", "limit", "Нет: 3/3 или ошибка")
    m.f("limit", "restore")
    m.f("manage", "merge")
    m.f("preview", "restore")
    m.chain("confirm_delete", "delete_choice")
    m.f("delete_choice", "delete", "Да")
    m.f("delete_choice", "restore", "Нет: отмена")
    m.f("delete", "merge")

    m.chain("merge", "result")
    m.f("result", "sync", "Да: подтверждённый статус")
    m.f("result", "error", "Нет: отказ / ошибка")
    m.f("sync", "restore")
    m.chain("error", "retry_choice", "retry_route")
    m.f("retry_route", "retry", "Повторить")
    m.f("retry_route", "restore", "Вернуться")
    m.f("retry", "result")
    m.chain("restore", "end")
    return m


def _profile_model():
    m = Model(
        "U08",
        "Профиль, чаты, активности и личный Plus",
        (
            "Вход через нижний Профиль P07 либо напрямую в существующий chat_id "
            "из U05/U07 без обязательного посещения меню. "
            "Нормализованные пункты P07: Личный кабинет P02, Моя подписка P06, "
            "Сообщения и чаты P05, Мои активности P04, Мои комьюнити P03, "
            "Мои подписки P01 перед выходом, Выход и удалить профиль. "
            "В P03 только собственные Community; P01 — SocialFollow, не Membership. "
            "P02 редактирует тот же Profile/Interest регистрации: 1–5 фото, "
            "уникальный ник без учёта регистра, единые интересы, приватность и "
            "предпросмотр публичной проекции без публикации черновика. "
            "P05 фильтры Все/Личные/Групповые/Сообщества; один chat_id на контекст, "
            "Plan/Meeting не создают отдельный чат; ACL и серверные unread. "
            "Отправка отмечается Sent только после серверного ack, сбой сохраняет draft. "
            "P04 сохранённые карточки, кружки и запланированное показывают текущие "
            "ID/ACL/TTL; просмотр не продлевает карту и не прерывает разрешённый "
            "чат/Meeting после TTL объявления. "
            "P06 подключается добровольно: Plus $8/месяц, $80/год, trial 7 дней "
            "один раз; требование или отсутствие банковской карты не утверждается. "
            "Шесть прав только T0555: Ghost Mode; публичная аудитория своих "
            "разрешённых активностей/кружков/эфиров; Archive; лайкнувшие профиль "
            "и разрешённый контакт; личное облако 30–180 мин с открытым якорем; "
            "Travel-объявление отдельного слоя 3 часа в одной стране. "
            "Plus не Gold/Premium и не допуск к произвольному эфиру. "
            "Для оплаты требуется подтверждение провайдера; отмена автопродления "
            "сохраняет права до конца активного периода. "
            "Выход завершает сеанс без удаления аккаунта. Удаление требует отдельного "
            "подтверждения и согласованного регламента; сроки/каскады открыты. "
            "Каждое действие проверяет серверные session/ACL/role/TTL/entitlement; "
            "до подтверждения нельзя показывать успех. "
            "Возврат сохраняет исходный раздел, таб, фильтр, прокрутку и объект."
        ),
        ["UR08", "UR03", "UR06", "UR05", "UR07", "UR02", "UR04"],
        lanes=LANES,
    )
    m.sources = [
        "P0338", "P0348", "P0537", "P0539", "P0541", "P0543", "P0544",
        "P0545", "P0551", "P0554", "T0555", "P0564", "P0566", "P1107",
        "P1108", "P1109", "P1113", "P1114", "P1115", "P1119", "P1120",
        "P1121", "P1125", "P1126", "P1127", "P1131", "P1132", "P1133",
        "P2015", "P2016", "P2017", "P2164", "P2165", "P2166", "P2213",
        "P2214", "P2215", "P2218", "P2219", "P2220", "P2223", "P2224",
        "P2225", "P2228", "P2229", "P2230", "P2233", "P2234", "P2235",
        "P2254", "P2255", "P2256", "P2257", "P2259", "P2424", "P2426",
        "P2427", "P2428", "P2438", "P2447", "T0875", "T2420", "T2435",
    ]

    def n(id, name, col, lane, type="userTask", track=0, **kw):
        kw.setdefault("sources", ["P2164", "P2426"])
        kw.setdefault("certainty", "подтверждено/следствие")
        return m.n(id, name, col, lane, type=type, track=track, **kw)

    n("start", "Профиль или прямой чат", 0, 0, "startEvent",
      sources=["P2213", "P2229"])
    n("entry", "Откуда открыт сценарий?", 1, 1, "exclusiveGateway",
      sources=["P2213", "P2229"])
    n("menu", "Показать P07 и Мои подписки перед выходом", 2, 1,
      "serviceTask", sources=["P1108", "P2016", "P2214"],
      note="Меню/панель профиля; геометрия раскрытия не задана. Мои комьюнити "
           "означает созданные мной, а не любое членство. Unread с сервера.")
    n("choose", "Выбрать вложенный раздел или выход", 3, 0,
      sources=["P2016"])
    n("route", "Выбранный пункт P07?", 4, 0, "exclusiveGateway",
      sources=["P2016", "T2435"])

    n("profile", "Просмотреть / изменить свой Profile P02", 5, 0,
      sources=["P2218", "P2219", "P2427"],
      note="О себе, возраст, интересы, настройки приватности, фото. "
           "Посмотреть мой профиль — публичная разрешённая проекция, "
           "назад возвращает в кабинет; новое Profile не создаётся.")
    n("edit", "Сохранить изменения анкеты?", 6, 0,
      "exclusiveGateway", sources=["P1114", "P2026"],
      note="Просмотр, предпросмотр и возврат не требуют изменения анкеты.")
    n("save", "Проверить 1–5 фото, ник и сохранить Profile", 7, 2,
      "serviceTask", sources=["P0338", "P0348", "P2220", "P2427", "P2438"],
      note="Ник уникален без учёта регистра; единые Profile/Interest. "
           "Ошибка не публикует частично сохранённый черновик.")

    n("filters", "Показать P05: поиск и 4 фильтра", 5, 1,
      "serviceTask", track=1, sources=["P2228", "P2229"],
      note="Все / Личные / Групповые / Сообщества; только разрешённые "
           "Conversation, серверные unread. Запрос списка каждый раз проверяет ACL; "
           "фильтры не меняют права. Пусто/сеть/ошибка/нет доступа различаются.")
    n("list_state", "Состояние списка P05 и действие?", 6, 1,
      "exclusiveGateway", track=1, sources=["P2165", "P2228", "P2229"],
      note="Выбирать чат можно только при доступной строке. Повтор — только "
           "чтение/поиск списка, без Message или нового chat_id.")
    n("pick", "Выбрать существующую беседу", 6, 0, track=1,
      sources=["P2229"])
    n("direct", "Принять chat_id из U05 / U07", 2, 1,
      "serviceTask", track=1, sources=["P1126", "P2229"],
      note="Прямой вход из Signal/Moment/Travel/Event/Community обходит P07; "
           "не создаёт новую беседу вместо контекстной.")
    n("chat_acl", "Проверить участника и тот же chat_id", 7, 2,
      "serviceTask", track=1, sources=["P0539", "P0543", "P0544", "P0545", "P2447"],
      note="Plan/Meeting используют чат исходного контекста. TTL объявления "
           "не удаляет разрешённый чат. Скрытая команда бизнеса не раскрывается.")
    n("chat_access", "Чат доступен?", 8, 2, "exclusiveGateway", track=1)
    n("thread", "Показать беседу; синхронизировать unread", 9, 1,
      "serviceTask", track=1, sources=["P2229", "T2420"])
    n("chat_action", "Отправить сообщение или вернуться?", 10, 1,
      "exclusiveGateway", track=1, sources=["P2229", "P2164"],
      note="Чтение беседы не требует отправки сообщения.")
    n("compose", "Написать сообщение и отправить", 10, 0, track=1,
      sources=["P0538", "P2428"])
    n("send", "Проверить ACL и подтвердить запись Message", 11, 2,
      "serviceTask", track=1, sources=["P0545", "P2426", "P2428"],
      note="Повтор отправки идемпотентен. Сетевой запрос ещё не является "
           "подтверждённой записью; Sent возможен только после ack.")
    n("ack", "Сервер подтвердил сообщение?", 12, 2,
      "exclusiveGateway", track=1, sources=["P2424", "P2428"])
    n("sent", "Показать Sent после серверного ack", 13, 1,
      "serviceTask", track=1, sources=["P2424", "P2428"],
      certainty="инженерное следствие",
      note="Надпись Sent обозначает подтверждённую запись, не прочтение получателем.")
    n("draft", "Сохранить draft; показать сбой отправки", 13, 1,
      "serviceTask", track=2, sources=["P2165", "P2428"],
      certainty="инженерное следствие",
      note="Не показывать Sent; сохранить текст и контекст для безопасного повтора.")

    n("activities", "Выдать P04: Saved / Events / Moments / Circles", 5, 2,
      "serviceTask", track=2, sources=["P2233", "P2234", "P2235", "P2254", "P2257"],
      note="Единые ID, актуальные ACL/TTL. Сохранённое не становится постоянным "
           "маркером; кружок 90 минут на карте, оригинал ещё 30 дней/Archive.")
    n("activity_list", "Состояние списка P04 и действие?", 6, 1,
      "exclusiveGateway", track=2, sources=["P2165", "P2233", "P2234"],
      note="Пусто / сеть / ошибка / скрыто / истёкший маркер различаются. "
           "До выбора карточки разрешены возврат или повтор только чтения. "
           "TTL не продлевается, команда создания/участия не повторяется.")
    n("activity_pick", "Выбрать актуальную карточку активности", 7, 0,
      track=2, sources=["P2234"])
    n("activity_route", "Какой контекст активности?", 8, 0,
      "exclusiveGateway", track=2, sources=["P2234"])
    n("social", "Moment / Meeting / Travel · U05", 9, 1,
      "callActivity", track=2, called="U05",
      sources=["P2234", "P2255", "P2256"],
      note="Тот же контекст и chat_id; истечение поиска не прерывает подтверждённую Meeting.")
    n("activity_community", "Event / Community · U07", 9, 1,
      "callActivity", track=3, called="U07", sources=["P2234", "P2254"])
    n("communities", "P03 собственные / P01 Follow · U07", 5, 1,
      "callActivity", track=4, called="U07",
      sources=["P2214", "P2215", "P2248", "P2249"],
      note="Не объединять owner, Membership и SocialFollow; P03 max3, P01 feed по ACL.")

    n("plus", "Показать P06: $8 / $80, 7 дней и 6 прав", 5, 1,
      "serviceTask", track=5, sources=["P2223", "T0555"],
      note="Подключение optional; бесплатное ядро доступно. Trial ровно один "
           "раз; отсутствие/требование карты не утверждается. Шесть прав T0555 "
           "без рекламы, геопоиска людей и бизнес-прав.")
    n("plus_pick", "Выбрать тариф, trial или отмену продления", 6, 0,
      track=3, sources=["P2224", "P0566"])
    n("plus_route", "Действие с личным Plus?", 7, 0,
      "exclusiveGateway", track=3)
    n("grant", "Проверить trial / оплату и личный entitlement", 8, 2,
      "serviceTask", track=3, sources=["P2224", "P2428", "T2420"],
      note="Trial 7 дней однократно; месяц $8, год $80. Платные права только "
           "после подтверждения провайдера, без дубля платежа. "
           "Раздельно от Gold/Premium; не открывает бизнес-редактор.")
    n("cancel_renew", "Отменить автопродление; сохранить период", 8, 2,
      "serviceTask", track=4, sources=["P1120", "P2224"],
      note="До paidUntil права активного периода сохраняются; "
           "отмена автопродления не означает немедленное лишение Plus.")

    n("logout", "Завершить только текущий сеанс", 5, 2,
      "serviceTask", track=5, sources=["P2016", "P2214"],
      note="Выход не удаляет Profile, Community, медиа или историю.")
    n("logged_out", "Сеанс завершён", 6, 0, "endEvent", track=6,
      sources=["P2016"])
    n("delete_confirm", "Отдельно подтвердить удаление аккаунта", 5, 0,
      track=4, sources=["P2016", "P2424", "T0875"])
    n("delete_choice", "Удаление подтверждено?", 6, 0,
      "exclusiveGateway", track=4)
    n("delete", "Проверить и выполнить согласованное удаление", 7, 2,
      "serviceTask", track=6, sources=["P2424", "P2426", "T0875"],
      certainty="подтверждено; регламент открыт",
      note="Только согласованный lifecycle. Регламент ещё не подготовлен: "
           "при отсутствии согласованного действия результат — блокировка/уточнение, "
           "не выдуманный каскад удаления данных.")

    n("result", "Действие подтверждено сервером?", 10, 2,
      "exclusiveGateway", sources=["P2424", "P2428"])
    n("success", "Показать подтверждённый статус и те же ID", 11, 1,
      "serviceTask", sources=["P2166", "P2427"],
      note="Если повторяется Message — Sent только после его ack; "
           "не смешивать успех оплаты с отменой продления или удалением.")
    n("error", "Показать причину; сохранить исходные данные", 11, 1,
      "serviceTask", track=6, sources=["P2165", "P2428"],
      note="Нет ложного успеха; бесплатные разрешённые функции не блокируются из-за оплаты.")
    n("retry_choice", "Повторить команду или вернуться?", 13, 0,
      "exclusiveGateway", track=5)
    n("retry", "Повторить идемпотентно с проверкой ACL", 14, 2,
      "serviceTask", track=6, sources=["P2426", "P2428"],
      note="Сохранённые target ID и тип операции; для Message сохранить draft "
           "и дождаться ack, для оплаты не создавать второй платёж.")
    n("restore", "Вернуть источник, таб, фильтр и позицию", 14, 1,
      "serviceTask", sources=["P2164", "P2422"],
      note="Прямой чат возвращает в U05/U07; просмотр не продлевает TTL. "
           "При недоступном объекте показать актуальное состояние.")
    n("end", "Исходный контекст восстановлен", 15, 0, "endEvent")

    m.chain("start", "entry")
    m.f("entry", "menu", "Профиль P07")
    m.f("entry", "direct", "Прямой chat_id из U05 / U07")
    m.chain("menu", "choose", "route")
    m.f("route", "profile", "Личный кабинет P02")
    m.f("route", "filters", "Сообщения и чаты P05")
    m.f("route", "activities", "Мои активности P04")
    m.f("route", "communities", "Мои комьюнити P03 / подписки P01")
    m.f("route", "plus", "Моя подписка P06")
    m.f("route", "logout", "Выход")
    m.f("route", "delete_confirm", "Удалить профиль")

    m.chain("profile", "edit")
    m.f("edit", "save", "Да: сохранить")
    m.f("edit", "restore", "Нет: просмотр / назад")
    m.f("save", "result")
    m.chain("filters", "list_state")
    m.f("list_state", "pick", "Есть доступная беседа: выбрать")
    m.f("list_state", "filters", "Повторить только чтение / поиск")
    m.f("list_state", "restore", "Пусто / ошибка / нет доступа / назад")
    m.chain("pick", "chat_acl")
    m.chain("direct", "chat_acl", "chat_access")
    m.f("chat_access", "thread", "Да")
    m.f("chat_access", "error", "Нет / сеть / скрыто")
    m.chain("thread", "chat_action")
    m.f("chat_action", "compose", "Написать и отправить")
    m.f("chat_action", "restore", "Только чтение / назад")
    m.chain("compose", "send", "ack")
    m.f("ack", "sent", "Да: серверный ack")
    m.f("ack", "draft", "Нет: отказ / сбой")
    m.f("sent", "restore")
    m.f("draft", "retry_choice")

    m.chain("activities", "activity_list")
    m.f("activity_list", "activity_pick", "Есть доступная карточка: выбрать")
    m.f("activity_list", "activities", "Повторить только чтение")
    m.f("activity_list", "restore", "Пусто / ошибка / скрыто / назад")
    m.chain("activity_pick", "activity_route")
    m.f("activity_route", "social", "Moment / Meeting / Travel")
    m.f("activity_route", "activity_community", "Event / Community")
    m.f("activity_route", "restore", "Сохранённое / кружок / пусто / ошибка / назад")
    m.f("social", "restore")
    m.f("activity_community", "restore")
    m.f("communities", "restore")

    m.chain("plus", "plus_pick", "plus_route")
    m.f("plus_route", "grant", "Подключить тариф / trial")
    m.f("plus_route", "cancel_renew", "Отменить автопродление")
    m.f("plus_route", "restore", "Остаться бесплатно / назад")
    m.f("grant", "result")
    m.f("cancel_renew", "result")

    m.f("logout", "result")
    m.chain("delete_confirm", "delete_choice")
    m.f("delete_choice", "delete", "Да")
    m.f("delete_choice", "restore", "Нет: отмена")
    m.f("delete", "result")

    m.f("result", "success", "Да: действие кроме выхода / удаления")
    m.f("result", "logged_out", "Да: выход или удаление по регламенту завершены")
    m.f("result", "error", "Нет: отказ / ошибка / открытый регламент")
    m.f("success", "restore")
    m.f("error", "retry_choice")
    m.f("retry_choice", "retry", "Повторить")
    m.f("retry_choice", "restore", "Вернуться")
    m.f("retry", "result")
    m.chain("restore", "end")
    return m


def models() -> list[Model]:
    """Return U07 and U08 without writing generated model files."""
    return [_community_model(), _profile_model()]

