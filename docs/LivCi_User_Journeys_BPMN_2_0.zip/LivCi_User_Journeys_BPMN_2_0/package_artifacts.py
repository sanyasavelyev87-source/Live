"""Package checked artifacts. Browser smoke export must run first."""
from pathlib import Path
import hashlib,json,zipfile
from pypdf import PdfReader,PdfWriter

ROOT=Path(__file__).resolve().parent
TEMP=Path('/workspace/scratch/personal-diagram-pages')
def merge(ids,target):
    writer=PdfWriter()
    for id in ids:writer.append(str(TEMP/(id+'.pdf')))
    writer.add_metadata({'/Title':'LivCi · personal user journeys · BPMN 2.0','/Author':'LivCi process specification','/Subject':'Updated concept 15.10.2026; descriptive, non-executable BPMN'})
    writer.write(ROOT/target)

def digest(path):return hashlib.sha256(path.read_bytes()).hexdigest()

def package():
    for file in ['validation/structure-report.json','validation/browser-report.json','validation/document-source-report.json']:
        report=json.loads((ROOT/file).read_text());assert report['pass'],file
    merge(['U01','U02'],'LivCi_User_Journeys_Main.pdf')
    merge(['U%02d'%i for i in range(1,9)],'LivCi_User_Journeys_Diagrams.pdf')
    pdfs={p.name:len(PdfReader(p).pages) for p in ROOT.glob('*.pdf')}
    assert pdfs['LivCi_User_Journeys_Main.pdf']==2 and pdfs['LivCi_User_Journeys_Diagrams.pdf']==8
    (ROOT/'validation/pdf-report.json').write_text(json.dumps({'files':pdfs,'pass':True,'note':'Vector diagrams use natural page sizes; zoom for details.'},ensure_ascii=False,indent=2))
    files=sorted(p for p in ROOT.rglob('*') if p.is_file() and '__pycache__' not in p.parts and p.name!='CHECKSUMS.sha256')
    (ROOT/'CHECKSUMS.sha256').write_text(''.join(digest(p)+'  '+p.relative_to(ROOT).as_posix()+'\n' for p in files))
    files.append(ROOT/'CHECKSUMS.sha256')
    full=ROOT.parent/'LivCi_User_Journeys_BPMN_2_0.zip'
    with zipfile.ZipFile(full,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        for p in files:archive.write(p,'LivCi_User_Journeys_BPMN_2_0/'+p.relative_to(ROOT).as_posix())
    core=ROOT.parent/'LivCi_User_Journeys_BPMN_2_0_Light.zip'
    core_files=[p for p in files if p.suffix in ['.bpmn','.pdf','.svg'] or p.name in ['SPECIFICATION.md','model-index.json'] or p.parent==ROOT/'validation' and p.suffix=='.json']
    with zipfile.ZipFile(core,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as archive:
        archive.writestr('LivCi_User_Journeys_Light/README.txt','LivCi · BPMN 2.0 · 16.10.2026\n\nU01: первый вход после регистрации R09 → карта.\nU02: возвращение после закрытия, фона, восстановления связи или по ссылке.\nЕщё U03–U08: детализация последующих действий.\n\nОткройте LivCi_User_Journeys_Main.pdf для двух основных схем; LivCi_User_Journeys_Diagrams.pdf для всех восьми.\nСпецификация: LivCi_User_Journeys_Specification.pdf / SPECIFICATION.md.\nИмпорт в BPMN-редактор: LivCi_User_Journeys.bpmn (8 диаграмм) или models/U01.bpmn … U08.bpmn.\n\nЭто компактный комплект без HTML-просмотрщика и исходных изображений. Они входят в полный ZIP.\nМодели неисполняемые. Проверены файлы и просмотр; API и платежи приложения не тестировались.\n')
        for p in core_files:archive.write(p,'LivCi_User_Journeys_Light/'+p.relative_to(ROOT).as_posix())
    rows=[]
    for archive in [full,core]:
        with zipfile.ZipFile(archive) as z:
            assert z.testzip() is None
            names=z.namelist();assert sum('/models/' in n and n.endswith('.bpmn') for n in names)==8
            if archive==full:assert sum('/references/' in n and n.endswith(('.png','.jpg')) for n in names)==17
        rows.append({'file':archive.name,'bytes':archive.stat().st_size,'sha256':digest(archive),'entries':len(names),'crcValid':True})
    (ROOT.parent/'personal-journeys-package-report.json').write_text(json.dumps({'archives':rows,'pdfs':pdfs,'pass':True},ensure_ascii=False,indent=2))
    print(json.dumps({'archives':rows,'pdfs':pdfs,'pass':True},ensure_ascii=False,indent=2))

if __name__=='__main__':package()
