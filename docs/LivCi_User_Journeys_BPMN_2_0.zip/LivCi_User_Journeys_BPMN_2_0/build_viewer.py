from pathlib import Path
import json,os

ROOT=Path(__file__).resolve().parent
TOOLS=Path(os.environ.get('LIVCI_BPMN_TOOLING','/workspace/scratch/livci-bpmn-tooling/node_modules'))

def safe_json(value):return json.dumps(value,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c')

models=json.loads((ROOT/'model-index.json').read_text())
for model in models:model['xml']=(ROOT/model['file']).read_text()
parts=[p.read_text() for p in sorted((ROOT/'sections').glob('*.md'))]
spec='\n\n---\n\n'.join(parts)
(ROOT/'SPECIFICATION.md').write_text(spec)
data={'models':models,'spec':spec,'references':json.loads((ROOT/'references/index.json').read_text())}
template=(ROOT/'viewer.template.html').read_text()
replacements={'__BPMN_CSS__':(TOOLS/'bpmn-js/dist/assets/diagram-js.css').read_text()+'\n'+(TOOLS/'bpmn-js/dist/assets/bpmn-js.css').read_text(),'__BPMN_JS__':(TOOLS/'bpmn-js/dist/bpmn-navigated-viewer.production.min.js').read_text(),'__MARKED_JS__':(TOOLS/'marked/lib/marked.umd.js').read_text(),'__DATA__':safe_json(data)}
for marker,value in replacements.items():
    assert marker in template
    template=template.replace(marker,value)
(ROOT/'index.html').write_text(template)
notice='This viewer includes bpmn-js 18.31.0 and marked 17.0.4. The bpmn.io attribution remains visible. Original notices follow.\n\n'
for package in ['bpmn-js','marked']:
    for candidate in ['LICENSE','LICENSE.md']:
        file=TOOLS/package/candidate
        if file.exists():notice+='\n'+package+'\n'+file.read_text()+'\n';break
(ROOT/'THIRD_PARTY_NOTICES.txt').write_text(notice)
print('Viewer:',(ROOT/'index.html').stat().st_size,'bytes; specification:',len(spec),'characters; models:',len(models))
