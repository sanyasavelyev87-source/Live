"""Build the personal-user journeys from the 15 October 2026 concept."""
from pathlib import Path
from copy import deepcopy
import json
from lxml import etree as E
from bpmn_core import Model, write_model, NS

ROOT=Path(__file__).resolve().parent
LANES=('Пользователь · действие и выбор','Приложение LivCi · экран и контекст','LivCi · сервер, данные и права')
models=[]
def model(id,title,purpose,refs,sources):
    m=Model(id,title,purpose,refs,lanes=LANES);m.sources=sources;models.append(m);return m

m=model('U01','Первый вход после регистрации','Начало после подтверждённого R09: переход на карту без повторной анкеты, обязательной оплаты или общего запроса GPS. Ошибки загрузки не превращаются в успешный вход.',['DR09','UR15','DP16'],['P2315','P2317','P2162','P2165','P2220','P2171'])
m.n('s','Регистрация завершена · R09',0,type='startEvent',sources=['P2315','P2317'])
m.n('go','Нажать «Перейти к карте»',1,sources=['P2315','P2316'])
m.n('load','Загрузка карты и исходного контекста',2,1,type='serviceTask')
m.n('bootstrap','Прочитать существующий профиль, права и актуальные данные',3,2,type='serviceTask',sources=['P2169','P2220','P2426'])
m.n('result','Ответ сервера?',4,2,type='exclusiveGateway')
m.n('map','Показать P14 / P16 · карту и пять разделов',5,1,sources=['P2162','P2317'])
m.n('ready','Карта готова · свободный выбор U03',6,1,type='endEvent')
m.n('error','Показать ошибку / нет сети; сохранить контекст',5,1,track=1,sources=['P2165','P2171'])
m.n('retry','Повторить загрузку?',6,0,track=1,type='exclusiveGateway')
m.n('pause','Загрузка не завершена; можно вернуться',7,1,track=1,type='endEvent')
m.n('reauth','U02 · Восстановить вход',5,1,track=2,type='callActivity',called='U02',note='Только при явном ответе о недействительной сессии; не при сетевой неопределённости.')
m.n('handed','Продолжение через U02',6,1,track=2,type='endEvent')
m.chain('s','go','load','bootstrap','result');m.f('result','map','Данные готовы');m.chain('map','ready');m.f('result','error','Нет сети / ошибка');m.chain('error','retry');m.f('retry','bootstrap','Повторить');m.f('retry','pause','Позже');m.f('result','reauth','Сессия явно недействительна');m.chain('reauth','handed')

m=model('U02','Возвращение в приложение','Холодный запуск, возврат из фона, восстановление связи и уведомление/deep link. Сессия имеет три исхода; затем серверное обновление и разрешённая точка назначения.',['UR01','UR15','DP16','UR06'],['P2169','P1651','P1703','P1704','P2121','P2164','P2422','P2426','P2451'])
m.n('s','Запуск / foreground / reconnect / ссылка',0,type='startEvent')
m.n('entry','Сохранить тип входа и запрошенный контекст',1,1,type='serviceTask',certainty='инженерное уточнение',note='Не обещает сохранение deep link через переустановку или восстановление последней вкладки после холодного запуска.')
m.n('kind','Обычный холодный запуск?',2,1,type='exclusiveGateway')
m.n('splash','P15 · начальная загрузка',3,1,sources=['P2169'])
m.n('session','Проверить сессию по API',4,2,type='serviceTask',sources=['P2426','P1207'])
m.n('sessionResult','Состояние сессии?',5,2,type='exclusiveGateway')
m.n('auth','Личный вход: телефон / email / Google / Apple',6,0,track=1,sources=['T0611','P0612'],note='Регистрация нового аккаунта находится вне основного пути. SMS не навязывается другим методам.')
m.n('accountType','R01 · Выбрать тип аккаунта',6,0,track=2,sources=['P2169','P2268'])
m.n('role','Выбран личный маршрут?',7,0,track=2,type='exclusiveGateway')
m.n('business','Бизнес-маршрут BV01 / BV02 · вне личного процесса',8,1,track=5,type='endEvent',sources=['P2268'])
m.n('authResult','Результат входа?',7,2,track=1,type='exclusiveGateway')
m.n('incomplete','Передать в незавершённую регистрацию',8,1,track=2,type='endEvent',certainty='инженерное уточнение',note='Точная политика восстановления шага не задана. Подтверждённый контакт не равен завершённому профилю R09.')
m.n('cancel','Вход отменён · приватные данные недоступны',8,1,track=3,type='endEvent')
m.n('offline','Нет сети / ошибка · ограниченный безопасный режим',6,1,track=4,certainty='инженерное уточнение',sources=['P1703','P1704','P2165'],note='Точный offline UI и допуск к приватному локальному кэшу требуют отдельного решения. Кэш не подтверждает сессию, права, оплату или вместимость.')
m.n('retry','Повторить после восстановления связи?',7,0,track=4,type='exclusiveGateway')
m.n('offlineEnd','Офлайн: серверные действия не подтверждены',8,1,track=4,type='endEvent')
m.n('fresh','Сверить данные, ACL, сроки, подписку и непрочитанное',9,2,type='serviceTask',sources=['P1651','P1704','P1552','P1567','P1617','P1618','P1619','T2420'],note='Reconnect требует API resync. Проверка при foreground — инженерная реализация актуальности; не требование каждый раз заново загружать все медиа.')
m.n('freshResult','Свежий ответ получен?',10,2,type='exclusiveGateway')
m.n('target','Какой сохранённый тип входа?',11,1,type='exclusiveGateway')
m.n('deep','U04 · Проверить entity_type + ID, ACL и TTL',12,1,track=1,type='callActivity',called='U04',sources=['P2121','P2422'],note='Открыть целевой объект или явную причину недоступности, а не молча отправлять на главную.')
m.n('context','Восстановить вкладку, фильтры, скролл и разрешённый объект',12,1,track=2,sources=['P2164','P2422'],note='Только сохранённый контекст живого возврата/связи. Истёкшие сущности получают актуальный статус; TTL не перезапускается.')
m.n('home','Показать главную карту P14 / P16',12,1,sources=['P2169'])
m.n('end','Вход восстановлен · далее U03',13,1,type='endEvent')
m.chain('s','entry','kind');m.f('kind','splash','Да');m.f('kind','session','Нет · фон / связь / ссылка');m.chain('splash','session','sessionResult');m.f('sessionResult','fresh','Действительна');m.f('sessionResult','accountType','Явно недействительна / нет входа');m.f('sessionResult','offline','Неизвестно · сеть / ошибка');m.chain('accountType','role');m.f('role','auth','Личный');m.f('role','business','Бизнес');m.chain('auth','authResult');m.f('authResult','fresh','Вход выполнен · профиль завершён');m.f('authResult','incomplete','Регистрация не завершена');m.f('authResult','cancel','Отмена');m.f('authResult','auth','Ошибка данных · исправить');m.f('authResult','offline','Ошибка сети');m.chain('offline','retry');m.f('retry','session','Да');m.f('retry','offlineEnd','Позже');m.chain('fresh','freshResult');m.f('freshResult','target','Да');m.f('freshResult','offline','Ошибка / нет сети');m.f('freshResult','accountType','Сессия отклонена');m.f('target','deep','Уведомление / deep link');m.f('target','context','Фон / reconnect + контекст');m.f('target','home','Обычный холодный запуск / нет контекста');m.chain('deep','end');m.chain('context','end');m.chain('home','end')

m=model('U03','Общая навигация и возврат','Пять направлений личного аккаунта. Создать — действие, а не обычная лента. Выборы на шлюзах описывают намерение пользователя и не вводят новые диалоги.',['UR15','UR14','UR12','UR11','UR08'],['P2162','P2163','P2164','P2165','P2422','P2427'])
m.n('s','Карта / текущий разрешённый экран',0,type='startEvent')
m.n('snapshot','Запомнить экран, вкладку, фильтры, скролл и объект',1,1,type='serviceTask')
m.n('nav','Что выбрал пользователь?',2,0,type='exclusiveGateway')
for id,label,called,track in [('map','Карта · U04','U04',0),('people','Люди · Знакомства / Тревел','U04',1),('create','Создать · P11 / U06','U06',2),('communities','Сообщества · U07','U07',3),('profile','Профиль · P07 / U08','U08',4)]:
    m.n(id,label,3,1,type='callActivity',called=called,track=track,note='Для «Люди»: свободный поиск Тревел и карточки используют U04; социальное действие — U05.' if id=='people' else '')
    m.f('nav',id,{'map':'Карта','people':'Люди','create':'Создать','communities':'Сообщества','profile':'Профиль'}[id]);m.f(id,'state')
m.n('state','Отобразить фактический результат / пусто / ошибку',4,1,sources=['P2165','P2171'])
m.n('next','Следующее действие?',5,0,type='exclusiveGateway')
m.n('back','Назад / X · восстановить источник и актуальные данные',6,1,track=1,sources=['P2164','P2422'])
m.n('end','Контекст сохранён · пользователь продолжает',7,1,type='endEvent')
m.chain('s','snapshot','nav');m.chain('state','next');m.f('next','snapshot','Другой раздел / действие');m.f('next','back','Назад / закрыть');m.f('next','end','Остаться / завершить');m.chain('back','end')

m=model('U04','Карта, геодоступ и открытие объекта','Публичная карта не является каталогом GPS профилей. Разрешение спрашивается только для действия с реальными координатами; чтение и deep link проверяют серверные права и срок.',['UR15','DP16','UR14','UR13'],['P0244','P0248','P0253','P1555','P1559','P1567','P2121','P2175','P2433','P2453','P2458'])
m.n('s','Карта / Люди / карточка / ссылка по ID',0,type='startEvent')
m.n('origin','Какой раздел открыт?',1,0,track=3,type='exclusiveGateway')
m.n('dating','P13 · Знакомства: форматы, Open to Life, Signal, активности',2,1,track=3,sources=['P2183','P2184'])
m.n('peopleIntent','Действие на P13?',3,0,track=3,type='exclusiveGateway')
m.n('filters','Открыть форму формата и фильтры',4,0,track=3,sources=['P2184','P2185'],note='Свидание: возраст и рост обязательны; знакомства/компания: также пол и кого ищу; интересы необязательны. Не свайп-лента анкет.')
m.n('otl','Открыть редактор Open to Life и выбрать состояние',4,0,track=4,sources=['P2184'])
m.n('otlSave','Сохранить состояние; дождаться серверного ответа',5,2,track=4,type='serviceTask',sources=['P2186','P2451'])
m.n('otlAck','Ответ подтверждён?',6,2,track=4,type='exclusiveGateway')
m.n('otlError','Ошибка сохранения · сохранить выбранное состояние и контекст',6,1,track=4,sources=['P2186','P2451'])
m.n('socialEntry','U05 · Создать Signal / Moment или откликнуться',5,1,track=3,type='callActivity',called='U05',sources=['P2184'])
m.n('travel','P12 · Направления, поездки, места; поиск бесплатный',2,1,track=5,sources=['P2188','P0531'])
m.n('travelIntent','Действие на P12?',3,0,track=5,type='exclusiveGateway')
m.n('travelFilter','Выбрать направление / даты, отфильтровать предложения',4,0,track=5,sources=['P2189'])
m.n('travelSelect','Выбрать ID поездки и запросить актуальную карточку',4,1,track=5,sources=['P2189','P2426'])
m.n('travelCreate','U06 · Создать объявление Тревел',5,1,track=5,type='callActivity',called='U06',sources=['P2189','P2190'])
m.n('need','Нужны реальные координаты для выбранной функции?',1,1,type='exclusiveGateway',note='Например, Signal / «моя позиция». Смена города и просмотр доступных объектов не дают права раскрывать GPS профилей.')
m.n('permission','Контекстно запросить геодоступ ОС',2,0,track=1)
m.n('granted','Доступ и координаты доступны?',3,1,track=1,type='exclusiveGateway')
m.n('geo','Проверить реальные координаты для функции',4,2,track=1,type='serviceTask',sources=['P0244','P1555'],note='Для Signal фиксированные 1,5 км; центр карты не заменяет позицию пользователя.')
m.n('limited','Объяснить ограничение этой функции; сохранить контекст',4,1,track=2,certainty='инженерное уточнение',note='Отказ GPS не закрывает весь личный аккаунт. Точный экран отказа не утверждён.')
m.n('limitedEnd','Функция с геоданными не выполнена',5,1,track=2,type='endEvent')
m.n('read','Прочитать актуальные сущности: ACL, блокировки, TTL по времени БД',5,2,type='serviceTask',sources=['P1552','P1567','P2426'])
m.n('result','Результат чтения?',6,2,type='exclusiveGateway')
m.n('view','Это карта / поиск или целевой объект?',7,1,type='exclusiveGateway')
m.n('map','Серверные фильтры → кластеры по масштабу → карта',8,1,sources=['P1559','P1561','P2433'],note='Четыре канонических временных режима NOW/TODAY/WEEKEND/LATER. Подписи P14/P16 не имеют утверждённого соответствия; тема карты по часовому поясу показанного города.')
m.n('list','Показать разрешённые результаты формата / список поездок',8,1,track=5,sources=['P2184','P2188','P2189'],note='Не заменять поиск Тревел только картой. Сохранить направление, фильтры и позиции результатов.')
m.n('card','Показать разрешённую актуальную карточку',8,1,track=1,note='Обычный профиль не становится постоянным GPS маркером. Карточка и маркер имеют разные условия жизни.')
m.n('intent','В карточке выбрано разрешённое социальное действие?',9,0,track=1,type='exclusiveGateway')
m.n('social','U05 · Запрос / участие / встреча',10,1,track=1,type='callActivity',called='U05')
m.n('expired','Скрыть истёкший маркер; проверить доступ к стабильной карточке',7,2,track=2,type='serviceTask')
m.n('stable','Стабильная карточка разрешена?',8,2,track=2,type='exclusiveGateway')
m.n('unavailable','Показать причину: скрыто / нет прав / истекло / пусто',9,1,track=3,sources=['P2165','P2422'])
m.n('network','Показать ошибку сети, не выдавать кэш за актуальное',7,1,track=4)
m.n('retry','Повторить чтение?',8,0,track=4,type='exclusiveGateway')
m.n('wait','Состояние не подтверждено; контекст сохранён',9,1,track=4,type='endEvent')
m.n('back','Назад · вкладка / фильтры / скролл / источник',11,1,sources=['P2164','P2422'])
m.n('end','Просмотр / результат завершён',12,1,type='endEvent')
m.chain('s','origin');m.f('origin','need','Карта / целевой объект');m.f('origin','dating','Люди · Знакомства');m.f('origin','travel','Люди · Тревел');m.chain('dating','peopleIntent');m.f('peopleIntent','filters','Свидание / Знакомства / Компания / М+Ж');m.f('peopleIntent','otl','Open to Life');m.f('peopleIntent','socialEntry','Signal / активность / создать встречу');m.f('peopleIntent','back','Назад');m.chain('filters','need');m.chain('otl','otlSave','otlAck');m.f('otlAck','back','Да · сохранено');m.f('otlAck','otlError','Ошибка · без ложного успеха');m.chain('otlError','back');m.chain('socialEntry','back');m.chain('travel','travelIntent');m.f('travelIntent','travelFilter','Поиск / направление');m.f('travelIntent','travelSelect','Выбрать поездку');m.f('travelIntent','travelCreate','Создать поездку');m.f('travelIntent','back','Назад');m.chain('travelSelect','read');m.chain('travelFilter','need');m.chain('travelCreate','back');m.f('need','permission','Да');m.f('need','read','Нет');m.chain('permission','granted');m.f('granted','geo','Да');m.f('granted','limited','Отказ / недоступно');m.chain('limited','limitedEnd');m.chain('geo','read','result');m.f('result','view','Разрешено и актуально');m.f('result','expired','Срок маркера истёк');m.f('result','unavailable','Пусто / скрыто / запрещено');m.f('result','network','Нет сети / ошибка');m.f('view','map','Карта');m.f('view','list','Поиск формата / Тревел');m.f('view','card','Объект / deep link');m.chain('expired','stable');m.f('stable','card','Да');m.f('stable','unavailable','Нет');m.chain('network','retry');m.f('retry','read','Повторить');m.f('retry','wait','Позже');m.chain('map','back');m.chain('list','back');m.chain('card','intent');m.f('intent','social','Да · действие доступно');m.f('intent','back','Только просмотр / Назад');m.chain('social','back');m.chain('unavailable','back','end')

def build():
    from model_social_create import models as social_models
    from model_community_profile import models as community_models
    all_models=models+social_models()+community_models()
    assert [m.id for m in all_models]==['U01','U02','U03','U04','U05','U06','U07','U08']
    source_ids={x['id'] for x in json.loads((ROOT/'sources/concept-blocks.json').read_text())}
    for m in all_models:
        for source in getattr(m,'sources',[]):assert source in source_ids,(m.id,source)
        for n in m.nodes:
            for source in n.get('sources',[]):assert source in source_ids,(m.id,n['id'],source)
            # Screen rendering/restoration is an application step, not a human task.
            if n['type']=='userTask' and n['lane']==1:n['type']='task'
    import re
    for m in all_models:m.title=re.sub(r'^U\d{2}\s*·\s*','',m.title)
    manifest=[write_model(m) for m in all_models]
    (ROOT/'model-index.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    master=E.Element('{'+NS['bpmn']+'}definitions',nsmap=NS,id='LivCi_User_Journeys_Definitions',targetNamespace='urn:livci:personal-journeys:2026-10-16',exporter='LivCi personal journeys specification',exporterVersion='1.0')
    diagrams=[]
    for row in manifest:
        doc=E.parse(str(ROOT/row['file']))
        for child in doc.getroot():
            if E.QName(child).localname=='BPMNDiagram':diagrams.append(deepcopy(child))
            else:master.append(deepcopy(child))
    for diagram in diagrams:master.append(diagram)
    for activity in master.findall('.//{'+NS['bpmn']+'}callActivity'):
        import re
        match=re.search(r'Детализация: (U\d{2})\.bpmn',' '.join(d.text or '' for d in activity.findall('{'+NS['bpmn']+'}documentation')))
        if match:
            activity.set('calledElement',match.group(1)+'_Process_main')
            for d in activity.findall('{'+NS['bpmn']+'}documentation'):
                if 'calledElement не задан' in (d.text or ''):d.text='Детализация: '+match.group(1)+'.bpmn; calledElement разрешён внутри объединённого комплекта. Модель неисполняемая.'
    E.ElementTree(master).write(ROOT/'LivCi_User_Journeys.bpmn',encoding='UTF-8',xml_declaration=True,pretty_print=True)
    print(json.dumps({'models':len(manifest),'nodes':sum(x['nodes'] for x in manifest),'flows':sum(x['flows'] for x in manifest)},ensure_ascii=False))

if __name__=='__main__':build()
