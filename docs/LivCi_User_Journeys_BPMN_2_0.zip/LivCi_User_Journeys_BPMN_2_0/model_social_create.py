"""U05/U06: voluntary PERSONAL social participation and contextual creation.

The diagrams are non-executable views. Pending requests end the current viewing
pass; reopening reads the same server state rather than resubmitting a request.
"""
from bpmn_core import Model


LANES = (
    "User · Пользователь PERSONAL",
    "Client · Приложение LivCi",
    "Server · Сервер LivCi",
)


def _add(m, id, name, col, lane, sources, type="userTask", track=0,
         certainty="подтверждено", **kw):
    return m.n(id, name, col, lane, type=type, track=track,
               sources=sources, certainty=certainty, **kw)


def _social():
    m = Model(
        "U05", "U05 · Социальный цикл: запрос → встреча → связь",
        "Добровольное создание Signal/Moment и путь участника "
        "Signal/Moment/Event. Запрос и его "
        "состояние проверяются сервером. Pending завершает текущий просмотр, "
        "не превращаясь в бесконечную задачу ожидания. Принятый контекст "
        "ведёт в тот же chat_id; Meeting завершается только строгим "
        "большинством, Connection — после встречи и по взаимному согласию.",
        ["UR14", "UR10", "UR06", "UR05"], lanes=LANES,
    )
    m.sources = ["P0125", "P0127", "P0128", "P0129", "P0130", "P0131",
                 "P0132", "P0133", "P0134", "P0145", "P0149", "P0247",
                 "P0295", "T0301", "P0313", "P0314", "P0315", "P0316",
                 "P0318", "P0665", "P2164", "P2184", "P2185", "P2199",
                 "P2229", "P2230", "P2425", "P2426", "P2428", "P2441",
                 "P2451"]
    a = lambda *args, **kw: _add(m, *args, **kw)
    a("start", "Открыта возможность или своя заявка", 0, 0,
      ["P2184", "P2199"], type="startEvent")
    a("choose", "Выбрать Signal / Moment / Event", 1, 0,
      ["P0125", "P0295", "T0301", "P2184", "P2185"],
      note="Формат и Intent независимы; обязательные фильтры применяются "
           "в своём сценарии. Это не каталог анкет поблизости.")
    a("request_choice", "Что хочет пользователь?", 2, 0,
      ["P0311", "P0313", "P2184", "P2164", "P2428"],
      type="exclusiveGateway",
      certainty="инженерное уточнение",
      note="Статус существующей заявки читается без повторной отправки.")
    a("create_form", "P13: подтвердить свой Signal / Moment", 3, 0,
      ["P0125", "P0295", "T0301", "P2184", "P2185", "P2316"],
      track=3,
      note="Выбрать формат и Intent независимо, заполнить обязательные "
           "фильтры сценария. Для Signal контекстно запросить недостающее "
           "геоправо; отказ не блокирует приложение. Moment описывает "
           "конкретную активность. Только явное подтверждение создаёт объект.")
    a("create_context", "Проверить условия и создать свой запрос", 4, 2,
      ["P0149", "P0247", "T0309", "P0311", "P2426", "P2428"],
      type="serviceTask", track=3,
      note="Атомарно и идемпотентно. Signal: реальная разрешённая "
           "геопозиция, 1,5 км, максимум один активный Signal, TTL 15 мин. "
           "Moment: набор 90 мин, вместимость включает автора. "
           "Отказ геоправ/недопуск не создаёт полчерновика.")
    a("create_ack", "Создание подтверждено сервером?", 5, 2,
      ["P2426", "P2428", "P2451"], type="exclusiveGateway", track=3)
    a("created_end", "Свой Signal / Moment создан", 6, 1,
      ["P0311", "P0312", "P0149", "P2451"],
      type="endEvent", track=3,
      note="Только созданный запрос, не ACCEPTED и не автоматический чат. "
           "Ответы других пользователей и решения автора — последующие "
           "явные действия в том же контексте.")
    a("without_request", "Просмотр завершён без нового запроса", 3, 1,
      ["P0313", "P2184"], type="endEvent", track=1,
      certainty="инженерное уточнение")
    a("send", "Подтвердить отклик / заявку", 3, 0,
      ["P0127", "P0313", "P2199"],
      note="Только явное действие создаёт SignalResponse/Participation. "
           "Создание самого Signal/Moment — другая ветвь этого выбора. "
           "Для заполненного Event пользователь может явно выбрать "
           "лист ожидания вместо гарантированного места.")
    a("cancel_command", "Проверить право; отозвать / отменить", 3, 2,
      ["P0313", "P0494", "P1799", "P2426", "P2428"],
      type="serviceTask", track=2,
      note="Явно выбранная отмена: свой непринятый SignalResponse можно "
           "отозвать, своё участие Event — отменить, в том числе после "
           "принятия. Проверить владельца и актуальное состояние; "
           "идемпотентный повтор, не автоматическая отмена по просмотру.")
    a("cancel_ack", "Отзыв / отмена подтверждены?", 4, 2,
      ["P2426", "P2428", "P2451"], type="exclusiveGateway", track=2)
    a("cancel_end", "Свой отзыв / отмена сохранены", 5, 1,
      ["P0313", "P0494", "P1799", "P2451"],
      type="endEvent", track=3,
      note="После отмены Event место сначала предлагается подходящему "
           "кандидату из листа ожидания, а не произвольно новому участнику.")
    a("eligibility", "Проверить ACL, TTL, радиус и места", 4, 2,
      ["P0128", "P0145", "P0247", "P2425", "P2426"], type="serviceTask",
      note="Signal: реальная разрешённая геопозиция, 1,5 км, 15 минут. "
           "Moment: набор 90 минут; инициатор входит во вместимость. "
           "У Event свои сроки/места; отсутствие места не обещает принятие.")
    a("eligible", "Запрос допустим сейчас?", 5, 2,
      ["P0128", "P1799", "P2425", "P2426"], type="exclusiveGateway")
    a("unavailable", "Показать причину недоступности", 6, 1,
      ["P2165", "P2426"], track=1, type="task")
    a("unavailable_end", "Запрос не принят к обработке", 7, 1,
      ["P2426", "P2451"], type="endEvent", track=1)
    a("persist", "Атомарно сохранить запрос", 6, 2,
      ["P2425", "P2428"], type="serviceTask")
    a("ack", "Сохранение подтверждено?", 7, 2,
      ["P2428", "P2451"], type="exclusiveGateway")
    a("ack_error", "Ошибка: без ложного успеха", 8, 1,
      ["P2428", "P2451"], track=2, type="task",
      note="Контекст сохраняется. Повтор команды идемпотентен; "
           "текущее прохождение не застревает в ожидании.")
    a("ack_error_end", "Возврат к сохранённому контексту", 9, 1,
      ["P2164", "P2428"], type="endEvent", track=2,
      certainty="инженерное уточнение")
    a("submitted", "Показать подтверждённую заявку", 8, 1,
      ["P0313", "P2199", "P2451"], type="task")
    a("read_status", "Получить актуальное состояние", 9, 2,
      ["P0128", "P0314", "P0318", "P2199", "P2426"],
      type="serviceTask",
      certainty="инженерное уточнение",
      note="Снимок состояния. Принятие/отклонение — явное решение "
           "создателя объекта, другой стороны, а не автоматический "
           "результат отправки или чтения. Сервер возвращает это решение. "
           "Повторный просмотр не создаёт новую заявку.")
    a("status", "Состояние запроса?", 9, 2,
      ["P0313", "P0314", "P0318", "P1799", "P2199"],
      type="exclusiveGateway", track=1)
    a("pending_end", "PENDING: вернуться, статус сохранён", 10, 1,
      ["P0313", "P2199", "P2164"], type="endEvent", track=1,
      certainty="инженерное уточнение",
      note="Конец текущего просмотра, а не заявки. Позднее пользователь "
           "может открыть существующую заявку или уведомление. "
           "Универсальный таймер решения для Event не выдумывается.")
    a("waitlist", "Event: открыть очередь / ответить на offer", 10, 0,
      ["P0494", "P1799", "P2046", "P2425"], track=3,
      note="WAITLISTED не означает место. При освобождении места "
           "первый подходящий кандидат получает приглашение на 30 минут. "
           "Подтверждение участия — отдельное явное действие кандидата.")
    a("offer_choice", "Принять доступный offer ≤30 мин?", 11, 0,
      ["P2046", "P2425"], type="exclusiveGateway", track=3)
    a("offer_recheck", "Перепроверить offer и место атомарно", 12, 2,
      ["P0128", "P2046", "P2425", "P2426", "P2428"],
      type="serviceTask", track=3,
      note="Проверить кандидата, срок, ACL и свободное место при записи. "
           "Одновременное подтверждение не допускает переполнения.")
    a("offer_result", "Участие действительно принято?", 13, 2,
      ["P2425", "P2451"], type="exclusiveGateway", track=3)
    a("waitlist_end", "Без нового места: актуальный статус очереди", 14, 1,
      ["P1799", "P2046", "P2425"], type="endEvent", track=3,
      certainty="инженерное уточнение",
      note="Нет offer, отказ, истечение или проигранная гонка не дают "
           "ACCEPTED. При неподтверждении за 30 минут предложение "
           "переходит следующему. Дальнейший статус очереди — по "
           "серверным правилам, без гарантии места или вечного ожидания.")
    a("rejected", "Показать отклонение", 10, 1,
      ["P0128", "P0314"], track=2, type="task",
      note="Отказ на SignalResponse не требует объяснения.")
    a("rejected_end", "REJECTED: без встречи и нового чата", 11, 1,
      ["P0314", "P0315"], type="endEvent", track=2)
    a("expired", "Запрос истёк / отменён", 12, 1,
      ["P0149", "P0318", "P2165"], track=2, type="task",
      note="Новые отклики не принимаются. TTL не возрождается повтором.")
    a("expired_end", "Текущий непринятый запрос завершён", 13, 1,
      ["P0318", "P2441"], type="endEvent", track=2)
    a("chat", "ACCEPTED: открыть тот же chat_id", 10, 1,
      ["P0129", "P0315", "P2229", "P2230"], type="callActivity",
      called="U08", note="Только разрешённая существующая контекстная "
           "беседа. Вызов U08 здесь ограничен открытием chat_id, "
           "без автоматического запуска нового социального цикла. "
           "Принятый чат/встреча не обрываются от TTL объявления.")
    a("context", "Какой источник встречи?", 11, 1,
      ["P0130", "P0131", "P0132"], type="exclusiveGateway")
    a("signal_agree", "Signal: согласовать публичное место", 12, 0,
      ["P0315", "P0316"])
    a("signal_mutual", "Обе стороны подтвердили?", 13, 2,
      ["P0132", "P0316"], type="exclusiveGateway")
    a("signal_place", "Раскрыть согласованное место", 14, 1,
      ["P0316"], type="task",
      note="Публичное место встречи, не текущий GPS человека.")
    a("signal_unconfirmed", "Нет взаимности: остаётся принятый чат", 14, 1,
      ["P0315", "P0316", "P0318"], type="endEvent", track=1,
      certainty="инженерное уточнение",
      note="Публичное место не раскрывать как подтверждённое. "
           "Этот конец не удаляет разрешённую беседу.")
    a("need_plan", "Moment: нужно согласование?", 12, 0,
      ["P0130"], type="exclusiveGateway", track=1)
    a("plan", "Согласовать Plan внутри Moment", 13, 0,
      ["P0130", "P0663"], track=1,
      note="Место, время или условия. Если они уже определены, "
           "дополнительная форма не обязательна.")
    a("event_place", "Event: место/время организатора", 12, 1,
      ["P0131", "P2199"], type="task")
    a("coordinated", "Договорённость доступна", 14, 2,
      ["P0130", "P0131", "P0316"], type="exclusiveGateway", track=1,
      certainty="инженерное уточнение")
    a("meeting", "Реальная встреча", 15, 0,
      ["P0133"], note="Истечение Signal/Moment не завершает встречу.")
    a("attendance", "Участники подтверждают участие", 15, 0,
      ["P0133"], track=1,
      note="Неявку конкретного участника вправе отметить только "
           "организатор; спорная отметка не влияет до проверки.")
    a("majority", "Подтвердили строго > 1/2?", 14, 2,
      ["P0133"], type="exclusiveGateway", track=2,
      note="Не по одному таймеру и не по простому окончанию расписания.")
    a("not_completed", "Нет большинства: не COMPLETED", 15, 1,
      ["P0133", "P0134", "P0665"], type="task", track=2,
      certainty="инженерное уточнение",
      note="Meeting не завершать автоматически. Connection опирается "
           "на состоявшуюся реальную встречу и взаимность, а не на "
           "выдуманную дополнительную предпосылку статуса COMPLETED.")
    a("complete", "Meeting → COMPLETED", 13, 2,
      ["P0133"], type="serviceTask", track=2)
    a("connection_intent", "Выбрать: нужна ли связь после встречи", 12, 0,
      ["P0134", "P0665"], track=2,
      note="Связь необязательна; тип каждый участник выбирает сам.")
    a("connection_mutual", "Оба согласны на Connection?", 11, 2,
      ["P0134", "P0665"], type="exclusiveGateway", track=2)
    a("connection", "Создать взаимный Connection", 10, 2,
      ["P0134", "P0665"], type="serviceTask", track=2)
    a("connected", "Связь создана после встречи", 9, 1,
      ["P0134", "P0665"], type="endEvent", track=3)
    a("without_connection", "Без Connection; встреча сохранена", 11, 1,
      ["P0134", "P0665"], type="endEvent", track=1,
      certainty="инженерное уточнение")

    m.chain("start", "choose", "request_choice")
    m.f("request_choice", "create_form", "Создать свой Signal / Moment")
    m.f("request_choice", "send", "Отправить отклик / заявку")
    m.f("request_choice", "read_status", "Открыть уже отправленный")
    m.f("request_choice", "cancel_command", "Отозвать отклик / отменить Event")
    m.f("request_choice", "without_request", "Ничего не создавать / выйти")
    m.chain("create_form", "create_context", "create_ack")
    m.f("create_ack", "created_end", "Да: создан Signal / Moment")
    m.f("create_ack", "unavailable", "Нет: GPS / ACL / условия")
    m.f("create_ack", "ack_error", "Нет подтверждения / ошибка")
    m.chain("send", "eligibility", "eligible")
    m.f("eligible", "persist", "Допустим: места доступны")
    m.f("eligible", "persist", "Event заполнен: выбран WAITLISTED")
    m.f("eligible", "unavailable", "Нет: TTL / ACL / радиус / места")
    m.chain("unavailable", "unavailable_end")
    m.chain("persist", "ack")
    m.chain("cancel_command", "cancel_ack")
    m.f("cancel_ack", "cancel_end", "Да: отзыв / отмена сохранены")
    m.f("cancel_ack", "unavailable", "Нет права / состояние не допускает")
    m.f("cancel_ack", "ack_error", "Ошибка / нет подтверждения")
    m.f("ack", "submitted", "Да: подтверждено")
    m.f("ack", "ack_error", "Нет / ошибка сети")
    m.chain("ack_error", "ack_error_end")
    m.chain("submitted", "read_status", "status")
    m.f("status", "pending_end", "PENDING: решения пока нет")
    m.f("status", "waitlist", "WAITLISTED: Event")
    m.f("status", "rejected", "REJECTED")
    m.f("status", "expired", "EXPIRED / CANCELLED")
    m.f("status", "chat", "ACCEPTED")
    m.f("status", "ack_error", "Состояние не получено")
    m.chain("waitlist", "offer_choice")
    m.f("offer_choice", "offer_recheck", "Да: явное подтверждение в срок")
    m.f("offer_choice", "waitlist_end", "Нет offer / отказ / истёк срок")
    m.chain("offer_recheck", "offer_result")
    m.f("offer_result", "chat", "Да: сервер подтвердил ACCEPTED")
    m.f("offer_result", "waitlist_end", "Нет: offer / место недействительны")
    m.f("offer_result", "ack_error", "Результат не подтверждён")
    m.chain("rejected", "rejected_end")
    m.chain("expired", "expired_end")
    m.chain("chat", "context")
    m.f("context", "signal_agree", "Signal")
    m.f("context", "need_plan", "Moment")
    m.f("context", "event_place", "Event")
    m.chain("signal_agree", "signal_mutual")
    m.f("signal_mutual", "signal_place", "Да: взаимное подтверждение")
    m.f("signal_mutual", "signal_unconfirmed", "Нет / ещё не подтверждено")
    m.chain("signal_place", "coordinated")
    m.f("need_plan", "plan", "Да: согласовать детали")
    m.f("need_plan", "coordinated", "Нет: всё уже определено")
    m.chain("plan", "coordinated")
    m.chain("event_place", "coordinated")
    m.chain("coordinated", "meeting", "attendance", "majority")
    m.f("majority", "complete", "Да: строгое большинство")
    m.f("majority", "not_completed", "Нет: недостаточно подтверждений")
    m.chain("not_completed", "connection_intent")
    m.chain("complete", "connection_intent", "connection_mutual")
    m.f("connection_mutual", "connection", "Да: оба согласны")
    m.f("connection_mutual", "without_connection", "Нет / не предлагать")
    m.chain("connection", "connected")
    return m


def _create():
    m = Model(
        "U06", "U06 · Создать: видео / фото / эфир / Travel",
        "P11 содержит четыре актуальных действия. Съёмка и публикация "
        "разделены; камера/микрофон запрашиваются по функции. Серверное "
        "подтверждение обязательно для успеха. Plus даёт Travel-объявление "
        "и разрешённую публичную аудиторию, но не самостоятельный допуск "
        "к эфиру. Отмена, отсутствие права и ошибка имеют конечный выход.",
        ["UR12", "UR13", "UR07"], lanes=LANES,
    )
    m.sources = ["P0355", "P0356", "P0370", "P0371", "P0397", "P0398",
                 "P0399", "P0404", "P0525", "P0526", "P0527", "P0531",
                 "P0532", "T0555", "P1101", "P2164", "P2190", "P2208",
                 "P2209", "P2210", "P2211", "P2224", "P2225", "P2426",
                 "P2428", "P2432", "P2451"]
    a = lambda *args, **kw: _add(m, *args, **kw)
    a("start", "Пользователь нажал «Создать»", 0, 0,
      ["P2162", "P2207"], type="startEvent")
    a("p11", "P11: четыре действия создания", 1, 1,
      ["P0355", "P1101", "P2208"], type="task",
      note="Видео круг / Фото / Прямой эфир / Тревел. "
           "P0356 с тремя основными действиями — остаточное расхождение; "
           "актуальный прямой перечень содержит четыре.")
    a("format", "Что выбрано на P11?", 2, 0,
      ["P2208"], type="exclusiveGateway")
    a("video", "Выбран видеокруг: запись ≤90 сек", 3, 1,
      ["P2208", "P2210"], type="task",
      note="90 секунд — предел записи. TTL показа кружка — 90 минут.")
    a("photo", "Выбрано фото", 3, 1,
      ["P2208"], type="task", track=1)
    a("live_eligibility", "Проверить самостоятельный допуск эфира", 3, 2,
      ["P0397", "P2209", "P2426"], type="serviceTask",
      note="Разрешённый Venue/Event-организатор, безопасность и ACL. "
           "Plus сам по себе не выдаёт основание начать эфир.")
    a("live_allowed", "Эфир разрешён этому автору?", 4, 2,
      ["P0397", "P2426"], type="exclusiveGateway")
    a("live_denied", "Нет допуска: эфир не запускается", 5, 1,
      ["P0397", "P2225"], type="task", track=2)
    a("travel_right", "Проверить личное право Plus Travel", 3, 2,
      ["P0526", "P2190", "P2426"], type="serviceTask", track=2)
    a("travel_allowed", "Право объявления активно?", 4, 2,
      ["P0526", "P2190"], type="exclusiveGateway", track=2)
    a("travel_no_right", "Как продолжить без Plus?", 5, 0,
      ["P0531", "P2224"], type="exclusiveGateway", track=2,
      certainty="инженерное уточнение",
      note="Платна публикация временного объявления, не вся вкладка Travel.")
    a("plus", "Открыть P06 по выбору пользователя", 6, 1,
      ["P2224", "P2225"], type="callActivity", track=2, called="U08",
      certainty="инженерное уточнение",
      note="Вызов ограничен личным Plus. Возврат к P11; "
           "публикация после покупки не запускается автоматически.")
    a("travel_search", "Открыть бесплатный поиск Travel", 6, 1,
      ["P0524", "P0531"], track=3,
      note="Поиск не ограничен радиусом Signal. Основной TRAVEL Moment "
           "и трёхчасовое объявление — разные объекты (P0532).")
    a("travel_form", "Travel: одна страна, даты и аудитория", 5, 0,
      ["P0525", "P0527", "P2189", "P2190"], track=1,
      note="Отдельный включаемый слой; объявление 3 часа, "
           "а поездка имеет свои даты.")
    a("permissions", "Разрешить камеру / нужный микрофон", 6, 0,
      ["P2209", "P2432"],
      note="Только для выбранной функции и до захвата. "
           "Уже достаточное разрешение не запрашивается заново; "
           "фото не требует произвольно всех разрешений.",
      certainty="инженерное уточнение")
    a("permission_ok", "Достаточное разрешение получено?", 7, 1,
      ["P2209", "P2432"], type="exclusiveGateway")
    a("permission_denied", "Отказ: повтор / настройки, без захвата", 8, 1,
      ["P2432"], type="task", track=2)
    a("capture_kind", "Какой медиарежим выбран?", 8, 1,
      ["P2208", "P2209"], type="exclusiveGateway")
    a("capture", "Снять фото / видеокруг ≤90 сек", 9, 0,
      ["P0404", "P2208", "P2210"],
      note="Встроенная камера: фронтальная/основная. "
           "Захват ещё не означает публикацию.")
    a("live_setup", "Подготовить и подтвердить старт эфира", 9, 0,
      ["P0397", "P0404", "P2209"], track=2,
      note="Только после самостоятельного допуска и разрешений.")
    a("preview", "Проверить черновик и аудиторию", 10, 0,
      ["P0370", "P2209", "P2428"],
      note="Кружки по умолчанию контактам; публичная аудитория "
           "собственных кружков — добровольное право Plus. "
           "Travel проверяется как отдельное объявление.")
    a("publish_choice", "Подтвердить публикацию?", 11, 0,
      ["P2209", "P2428"], type="exclusiveGateway",
      certainty="инженерное уточнение")
    a("validate", "Перепроверить автора, права и аудиторию", 12, 2,
      ["P2209", "P2426"], type="serviceTask",
      note="Проверка перед записью: сессия/ACL/блокировки/entitlement, "
           "Travel одна страна; для эфира самостоятельный допуск. "
           "Скрытия кнопки на клиенте недостаточно.")
    a("valid", "Серверные условия выполнены?", 13, 2,
      ["P2426"], type="exclusiveGateway")
    a("invalid", "Показать причину отказа", 12, 1,
      ["P2165", "P2426"], type="task", track=2)
    a("command", "Сохранить объект / начать разрешённый эфир", 14, 2,
      ["P2209", "P2428"], type="serviceTask",
      note="Идемпотентная команда. Неподтверждённый черновик "
           "не изображается опубликованным.")
    a("ack", "Результат сервера подтверждён?", 15, 2,
      ["P2211", "P2432", "P2451"], type="exclusiveGateway")
    a("error", "Ошибка: сохранить контекст без успеха", 14, 1,
      ["P2211", "P2428", "P2432", "P2451"], type="task", track=2)
    a("retry", "Безопасно повторить?", 13, 1,
      ["P2211", "P2428"], type="exclusiveGateway", track=2,
      certainty="инженерное уточнение")
    a("reconcile", "Сверить операцию по ID и тому же payload", 12, 2,
      ["P2428", "P2451"], type="serviceTask", track=3,
      certainty="инженерное уточнение",
      note="idempotency key / operation ID — инженерное средство "
           "идемпотентности, не новое продуктовое поле. Сверить "
           "серверный результат исходной команды, сохранить уже "
           "снятые медиа/Travel-черновик; не запускать камеру заново. "
           "Для эфира сверить и текущий lifecycle: завершённый "
           "эфир не перезапускается как результат повтора.")
    a("reconcile_result", "Что известно об исходной операции?", 11, 2,
      ["P2428", "P2451"], type="exclusiveGateway", track=3,
      certainty="инженерное уточнение")
    a("unconfirmed_end", "Результат неизвестен; успех не показан", 10, 1,
      ["P2428", "P2432", "P2451"], type="endEvent", track=3,
      certainty="инженерное уточнение",
      note="Сохранить исходный контекст/черновик и идентификатор операции. "
           "Не публиковать дубликат и не выдавать неизвестный исход за отказ "
           "или успех. Текущий просмотр имеет конечный выход.")
    a("result_kind", "Что подтверждено сервером?", 15, 1,
      ["P2209", "P2432"], type="exclusiveGateway")
    a("live", "Вести / завершить эфир ≤5 часов", 14, 0,
      ["P0398", "P0399", "P0404"], track=1,
      note="Сервер ограничивает длительность 5 часами; камера "
           "переключается без окончания. Круг Venue виден только "
           "пока Venue открыт. Закрытие маркера не означает "
           "автоматическое техническое прекращение передачи. "
           "Ручное завершение и технический обрыв могут закончить "
           "эфир раньше предела; сеть не подменяет серверный результат.")
    a("live_end", "Завершить эфир; обновить видимость", 13, 2,
      ["P0398", "P0401", "P0402"], type="serviceTask", track=2)
    a("published", "Показать подтверждённый результат", 14, 1,
      ["P0371", "P0525", "P2190", "P2210"], type="task",
      note="Кружок: 90 минут на карте. Travel: отдельный слой, "
           "3 часа, одна страна. Не постоянные маркеры и не срок поездки.")
    a("end", "Вернуться к доступному контексту", 15, 1,
      ["P2164", "P2211"], type="endEvent", track=3,
      certainty="инженерное уточнение")

    m.chain("start", "p11", "format")
    m.f("format", "video", "Видео круг")
    m.f("format", "photo", "Фото")
    m.f("format", "live_eligibility", "Прямой эфир")
    m.f("format", "travel_right", "Тревел")
    m.f("format", "end", "Закрыть P11 / X")
    m.chain("video", "permissions")
    m.chain("photo", "permissions")
    m.chain("live_eligibility", "live_allowed")
    m.f("live_allowed", "permissions", "Да: независимый допуск есть")
    m.f("live_allowed", "live_denied", "Нет: Plus не заменяет допуск")
    m.chain("live_denied", "end")
    m.chain("travel_right", "travel_allowed")
    m.f("travel_allowed", "travel_form", "Да: личный Plus активен")
    m.f("travel_allowed", "travel_no_right", "Нет: публикация недоступна")
    m.f("travel_no_right", "plus", "Открыть личный Plus")
    m.f("travel_no_right", "travel_search", "Искать поездки бесплатно")
    m.f("travel_no_right", "end", "Вернуться без объявления")
    m.chain("plus", "p11")
    m.chain("travel_search", "end")
    m.chain("travel_form", "preview")
    m.chain("permissions", "permission_ok")
    m.f("permission_ok", "capture_kind", "Да: достаточно для функции")
    m.f("permission_ok", "permission_denied", "Нет / отказ")
    m.chain("permission_denied", "end")
    m.f("capture_kind", "capture", "Фото / видео")
    m.f("capture_kind", "live_setup", "Разрешённый эфир")
    m.chain("capture", "preview", "publish_choice")
    m.f("publish_choice", "validate", "Да: явное подтверждение")
    m.f("publish_choice", "end", "Нет: отменить черновик")
    m.chain("live_setup", "validate", "valid")
    m.f("valid", "command", "Да: права и данные допустимы")
    m.f("valid", "invalid", "Нет: понятный отказ")
    m.chain("invalid", "end")
    m.chain("command", "ack")
    m.f("ack", "result_kind", "Да: сервер подтвердил")
    m.f("ack", "error", "Нет / сеть / ошибка")
    m.chain("error", "retry")
    m.f("retry", "reconcile", "Да: сверить исходную операцию")
    m.f("retry", "end", "Нет: сохранить контекст и выйти")
    m.chain("reconcile", "reconcile_result")
    m.f("reconcile_result", "result_kind", "Подтверждено: результат уже есть")
    m.f("reconcile_result", "validate", "Не сохранено: повторить тот же черновик")
    m.f("reconcile_result", "unconfirmed_end", "Пока неизвестно / сеть недоступна")
    m.f("result_kind", "live", "Эфир запущен")
    m.f("result_kind", "live_end", "Эфир уже завершён при сверке")
    m.f("result_kind", "published", "Кружок / Travel сохранён")
    m.chain("live", "live_end", "end")
    m.chain("published", "end")
    return m


def models() -> list[Model]:
    """Return the two model definitions without writing generated artifacts."""
    result = [_social(), _create()]
    for model in result:
        model.sources = sorted(set(model.sources).union(
            source for node in model.nodes for source in node["sources"]
        ))
    return result
