"""Generate portable, non-executable BPMN 2.0 collaboration models with DI."""
from pathlib import Path
from lxml import etree as E
import json

ROOT=Path(__file__).resolve().parent
NS={'bpmn':'http://www.omg.org/spec/BPMN/20100524/MODEL','bpmndi':'http://www.omg.org/spec/BPMN/20100524/DI','dc':'http://www.omg.org/spec/DD/20100524/DC','di':'http://www.omg.org/spec/DD/20100524/DI','xsi':'http://www.w3.org/2001/XMLSchema-instance'}
def el(parent,tag,**attrs):return E.SubElement(parent,'{'+NS[tag.split(':')[0]]+'}'+tag.split(':')[1],**{k:str(v) for k,v in attrs.items()})

class Model:
    def __init__(self,id,title,purpose,refs,lanes=('Представитель бизнеса · выданные права','LivCi · серверные проверки и данные')):
        self.id=id;self.title=title;self.purpose=purpose;self.refs=refs;self.pools=[{'id':'main','name':title,'lanes':list(lanes),'blackbox':False}];self.nodes=[];self.edges=[]
    def pool(self,id,name,lanes=(),blackbox=False):self.pools.append({'id':id,'name':name,'lanes':list(lanes),'blackbox':blackbox});return self
    def n(self,id,name,col,lane=0,type='userTask',track=0,pool='main',**kw):self.nodes.append(dict(id=id,name=name,col=col,lane=lane,type=type,track=track,pool=pool,**kw));return id
    def f(self,source,target,name='',**kw):self.edges.append(dict(source=source,target=target,name=name,**kw));return self
    def chain(self,*ids):
        for a,b in zip(ids,ids[1:]):self.f(a,b)
        return self

MODELS=[]
def model(*args,**kwargs):m=Model(*args,**kwargs);MODELS.append(m);return m

m=model('B00','Общий цикл бизнес-аккаунта','От регистрации до опубликованных данных, управления и взаимодействия с посетителем. Детали вынесены в B01–B13.',['BR01','BR04','BR11'])
m.n('s','Начало',0,type='startEvent');m.n('reg','B01 · Регистрация бизнеса',1,type='callActivity',called='B01');m.n('card','B02 · Заполнить карточку',2,type='callActivity',called='B02');m.n('home','Главная бизнес-кабинета',3);m.n('choice','Что изменить?',4,type='exclusiveGateway')
for id,label,col,track,call in [('status','B03 · Часы и статус',5,0,'B03'),('content','B04 · Меню и контент',5,1,'B04'),('events','B05 · События',5,2,'B05'),('team','B06 / B12 · Community, чаты, права',6,0,'B06'),('activity','B07 / B08 · Облака и эфиры',6,1,'B07'),('premium','B09–B11 · Premium',6,2,'B09')]:
    m.n(id,label,col,track=track,type='callActivity',called=call);m.f('choice',id,label.split(' · ')[-1]);m.f(id,'sync')
m.n('sync','Согласовать данные и публичную видимость',7,1,type='serviceTask');m.n('journey','B13 · Путь обычного пользователя',8,1,type='callActivity',called='B13');m.n('end','Цикл выполнен; бизнес продолжает работу',9,1,type='endEvent');m.chain('s','reg','card','home','choice');m.chain('sync','journey','end')

m=model('B01','Регистрация бизнеса','Отдельный BUSINESS-вход: телефон/email, код подтверждения и начальные данные Community. Нет регистрации через личную анкету или обязательной проверки документов.',['BR15','BR01','BR02','BR03','BR05','BR04'])
m.pool('delivery','Канал доставки кода: телефон или email',blackbox=True)
m.n('s','Выбран бизнес-аккаунт',0,type='startEvent');m.n('method','Выбрать телефон или email',1);m.n('contact','Ввести контакт для входа',2);m.n('valid','Контакт допустим?',3,1,type='exclusiveGateway');m.n('send','Сформировать и отправить код',4,1,type='sendTask');m.n('code','Ввести 6-значный код',5);m.n('check','Проверить код и ограничения попыток',6,1,type='serviceTask');m.n('correct','Код подтверждён?',7,1,type='exclusiveGateway');m.n('retry','Исправить / сменить контакт / запросить повтор',6,track=1);m.n('cooldown','Истёк интервал повтора?',7,track=1,type='exclusiveGateway');m.n('wait','Дождаться разрешённого повтора',8,track=1,type='intermediateCatchEvent',timer='${resendCooldownConfigured}');m.n('existing','Есть BUSINESS-аккаунт?',8,1,type='exclusiveGateway');m.n('login','Открыть существующий кабинет',9,1,type='serviceTask');m.n('initial','Создать Community: название, категория, описание, адрес',9);m.n('save','Проверить данные и завершить регистрацию',10,1,type='serviceTask');m.n('ok','Сохранение успешно?',11,1,type='exclusiveGateway');m.n('e','BUSINESS-аккаунт и рабочее пространство доступны',12,1,type='endEvent');m.n('cancel','Пользователь прервал регистрацию',1,track=1,type='endEvent')
m.chain('s','method','contact','valid');m.f('valid','contact','Ошибка');m.f('valid','send','Да');m.chain('send','code','check','correct');m.f('send','delivery','Код подтверждения',kind='message');m.f('correct','existing','Да');m.f('correct','retry','Нет / истёк');m.f('retry','contact','Изменить контакт');m.f('retry','code','Повторить ввод');m.f('retry','cooldown','Новый код');m.f('cooldown','send','Да');m.f('cooldown','wait','Нет');m.f('wait','send');m.f('existing','login','Да');m.f('login','e');m.f('existing','initial','Нет');m.chain('initial','save','ok');m.f('ok','e','Да');m.f('ok','initial','Исправить / повторить');m.f('method','cancel','Выход')

m=model('B02','Карточка заведения: редактирование и публичный вид','Один Venue и его сохранённая версия. Контакт входа не становится публичным контактом автоматически.',['BR09','BR11','BR16'])
m.n('s','Открыт редактор карточки',0,type='startEvent');m.n('access','Проверить сессию, объект и право изменения',1,1,type='serviceTask');m.n('allow','Доступ разрешён?',2,1,type='exclusiveGateway');m.n('denied','Данные не изменены; доступ ограничен',3,1,track=1,type='endEvent');m.n('load','Загрузить сохранённую версию',3,1,type='serviceTask');m.n('edit','Заполнить профиль, адрес, контакты, часы, медиа',4);m.n('choose','Действие редактора?',5,type='exclusiveGateway');m.n('preview','Предпросмотр как посетитель без публикации черновика',6);m.n('cancel','Отменить несохранённые изменения',6,track=1);m.n('validate','Повторно проверить права, поля и версию данных',6,1,type='serviceTask');m.n('valid','Проверки пройдены?',7,1,type='exclusiveGateway');m.n('save','Атомарно сохранить карточку',8,1,type='serviceTask');m.n('project','Обновить публичное представление и карту',9,1,type='serviceTask');m.n('e','Сохранённая карточка доступна по правам',10,1,type='endEvent');m.n('ec','Сохранённая версия не менялась',7,track=1,type='endEvent');m.chain('s','access','allow');m.f('allow','denied','Нет');m.f('allow','load','Да');m.chain('load','edit','choose');m.f('choose','preview','Предпросмотр');m.f('preview','edit');m.f('choose','cancel','Отменить');m.f('cancel','ec');m.f('choose','validate','Сохранить');m.chain('validate','valid');m.f('valid','edit','Ошибка / конфликт версии');m.f('valid','save','Да');m.chain('save','project','e')

m=model('B03','Открытость Venue и видимость на карте','Сохранение карточки и открытость заведения — разные состояния. Закрытие не удаляет меню, события, Community или аккаунт.',['BR11','BR16','BR07','BR08'])
m.n('s','Изменились часы, ручной статус или время',0,type='startEvent');m.n('trigger','Ручное изменение?',0,1,type='exclusiveGateway');m.n('input','Указать часы / ручной статус',1);m.n('auth','Проверить право; сохранить изменения',2,1,type='serviceTask');m.n('effective','Рассчитать статус в часовом поясе Venue',3,1,type='businessRuleTask');m.n('open','Venue открыт и доступен для карты?',4,1,type='exclusiveGateway');m.n('show','Показать разрешённый Venue-маркер',5,1,type='serviceTask');m.n('decor','Применить Premium, облако, погоду, эфир по правам',6,1,type='serviceTask');m.n('hide','Скрыть маркер, облако, погоду и круг эфира',5,1,track=1,type='serviceTask');m.n('keep','Сохранить карточку и содержимое',6,1,track=1,type='serviceTask');m.n('e','Публичная карта обновлена',7,1,type='endEvent');m.chain('s','trigger');m.f('trigger','input','Да');m.chain('input','auth','effective','open');m.f('trigger','effective','Нет: наступило время пересчёта');m.f('open','show','Да');m.chain('show','decor','e');m.f('open','hide','Нет');m.chain('hide','keep','e')

m=model('B04','Меню, услуги, медиа, публикации и рилсы','Управление ассортиментом и контентом без заказа, корзины, оплаты блюд и бронирования.',['BR13','BR14','BR12','BR16'])
m.n('s','Открыт раздел содержимого',0,type='startEvent');m.n('access','Проверить право на раздел и действие',1,1,type='serviceTask');m.n('kind','Что редактируется?',2,type='exclusiveGateway');m.n('menu','Категория / позиция: фото, имя, описание, цена',3);m.n('availability','Указать доступность и порядок',4);m.n('media','Выбрать медиа / публикацию / рилс',3,track=1);m.n('upload','Проверить и обработать файл; сохранить содержимое',4,1,track=1,type='serviceTask');m.n('errors','Файлы и данные допустимы?',5,1,type='exclusiveGateway');m.n('visibility','Выбрать разрешённую видимость',6);m.n('save','Повторно проверить доступ и сохранить',7,1,type='serviceTask');m.n('update','Обновить каталог и публичные материалы',8,1,type='serviceTask');m.n('e','Посетитель видит актуальные разрешённые данные',9,1,type='endEvent');m.chain('s','access','kind');m.f('kind','menu','Меню / услуги');m.chain('menu','availability','errors');m.f('kind','media','Медиа / публикация / рилс');m.chain('media','upload','errors');m.f('errors','kind','Нет: показать конкретную ошибку');m.f('errors','visibility','Да');m.chain('visibility','save','update','e')

m=model('B05','События: публикация, заявки, участие и чат','Событие имеет собственные дату, лимит, участников и контекст чата. Подпись в публикации не создаёт событие автоматически.',['BR10'])
m.pool('visitor','Обычный пользователь: просмотр и заявка',blackbox=True)
m.n('s','Создать / открыть событие',0,type='startEvent');m.n('edit','Указать название, время, описание, место и условия',1);m.n('save','Проверить права и сохранить Event',2,1,type='serviceTask');m.n('surface','Опубликовать в разделе событий; проверить карту',3,1,type='serviceTask');m.n('request','Получена заявка на участие',4,1,type='intermediateCatchEvent',message=True);m.n('check','Проверить доступ, повтор заявки и свободные места',5,1,type='serviceTask');m.n('capacity','Есть место и выполнены условия?',6,1,type='exclusiveGateway');m.n('decision','Рассмотреть заявку при требуемом согласовании',7);m.n('accept','Решение?',8,type='exclusiveGateway');m.n('member','Зафиксировать участие и доступ к чату события',9,1,type='serviceTask');m.n('waitlist','Лист ожидания / отказ согласно правилам Event',7,1,track=1,type='serviceTask');m.n('reply','Сообщить статус участия',10,1,type='sendTask');m.n('e','Статусы, счётчики и чат согласованы',11,1,type='endEvent');m.chain('s','edit','save','surface','request','check','capacity');m.f('surface','visitor','Доступное событие',kind='message');m.f('visitor','request','Заявка с event_id',kind='message');m.f('capacity','decision','Да');m.chain('decision','accept');m.f('accept','member','Принято / свободное участие');m.f('accept','waitlist','Отклонено');m.f('capacity','waitlist','Нет');m.f('waitlist','reply');m.chain('member','reply','e');m.f('reply','visitor','Текущий статус, не бронь/билет',kind='message')

m=model('B06','Community, заявки, участники и чаты','Членство, подписка на уведомления и административные права — разные разрешения. Внутренний чат команды не становится публичным.',['BR06','BR09','BR10'])
m.pool('member','Пользователь / кандидат в Community',blackbox=True)
m.n('s','Запрос вступления / открытие чата',0,type='startEvent',message=True);m.n('identify','Определить Community и права пользователя',1,1,type='serviceTask');m.n('path','Открытое или закрытое Community?',2,1,type='exclusiveGateway');m.n('pending','Сохранить заявку без доступа к закрытому',3,1,type='serviceTask');m.n('review','Уполномоченный сотрудник рассматривает заявку',4);m.n('decision','Принять?',5,type='exclusiveGateway');m.n('reject','Сохранить отказ; доступ не выдавать',6,1,track=1,type='serviceTask');m.n('join','Сохранить членство; обновить список',6,1,type='serviceTask');m.n('chat','Выбрать конкретный чат Community или Event',7);m.n('rights','Проверить участие, видимость и право чтения/отправки',8,1,type='serviceTask');m.n('allowed','Доступ есть?',9,1,type='exclusiveGateway');m.n('send','Открыть историю / сохранить сообщение',10,1,type='serviceTask');m.n('deny','Показать ограничение без чужих сообщений',10,1,track=1,type='serviceTask');m.n('e','Пользователь получил только разрешённый результат',11,1,type='endEvent');m.chain('s','identify','path');m.f('path','pending','Закрытое; не участник');m.chain('pending','review','decision');m.f('decision','reject','Нет');m.f('reject','e');m.f('decision','join','Да');m.f('path','join','Открытое: допустимо вступление');m.f('path','chat','Уже есть членство');m.chain('join','chat','rights','allowed');m.f('allowed','send','Да');m.f('allowed','deny','Нет');m.f('send','e');m.f('deny','e');m.f('member','s','Заявка / запрос чата',kind='message');m.f('send','member','Разрешённые сообщения',kind='message')

m=model('B07','Облака активности: бесплатно и Premium','BR07 задаёт 250 символов, 30 минут / 1 / 2 / 3 часа, одно бесплатное облако в календарный день, без одновременных активных облаков.',['BR07','BR08','BR11'])
m.n('s','Подготовить облако',0,type='startEvent');m.n('compose','Ввести текст до 250 символов и выбрать срок',1);m.n('validate','Проверить доступ, открытость, квоту и активное облако',2,1,type='serviceTask');m.n('allowed','Запуск разрешён?',3,1,type='exclusiveGateway');m.n('blocked','Показать причину; не списывать квоту',4,1,track=1,type='endEvent');m.n('publish','Атомарно создать облако и учесть квоту',4,1,type='serviceTask');m.n('active','Показывать сверху Venue-маркера по правам',5,1,type='serviceTask');m.n('timer','Истёк выбранный срок 30 мин–3 ч',6,1,type='intermediateCatchEvent',timer='${cloudDuration}');m.n('expire','Завершить облако; убрать его с карты',7,1,type='serviceTask');m.n('repeat','Premium и автоповтор включены?',8,1,type='exclusiveGateway');m.n('next','Следующий текст/параметры определены политикой?',9,type='exclusiveGateway');m.n('e','Облако завершено',10,1,type='endEvent');m.n('policy','Требуется согласованная политика повтора Q-A01',10,track=1,type='endEvent');m.chain('s','compose','validate','allowed');m.f('allowed','blocked','Нет');m.f('allowed','publish','Да');m.chain('publish','active','timer','expire','repeat');m.f('repeat','e','Нет');m.f('repeat','next','Да');m.f('next','validate','Да: запуск строго после предыдущего');m.f('next','policy','Нет')

m=model('B08','Прямой эфир заведения','Длительность не более 5 часов. Круг на карте виден только пока Venue открыт; закрытие не доказывает автоматическую остановку самого потока.',['BR07'])
m.n('s','Запрошен прямой эфир',0,type='startEvent');m.n('permissions','Разрешить камеру/микрофон и настроить эфир',1);m.n('guard','Проверить право публикации и доступность Venue',2,1,type='serviceTask');m.n('can','Запуск разрешён?',3,1,type='exclusiveGateway');m.n('no','Показать ошибку / ограничение',4,1,track=1,type='endEvent');m.n('start','Создать сессию трансляции',4,1,type='serviceTask');m.n('run','Вести эфир / завершить вручную',5);m.n('limit','Не более 5 часов',5,type='boundaryEvent',attached='run',timer='PT5H');m.n('stop','Завершить сессию; убрать активный круг',6,1,type='serviceTask');m.n('end','Эфир завершён; запись не обещана',7,1,type='endEvent');m.chain('s','permissions','guard','can');m.f('can','no','Нет');m.f('can','start','Да');m.chain('start','run','stop','end');m.f('limit','stop','Лимит времени');

m=model('B09','Подписка Business Premium и её срок','Подтверждено пользователем: 7 дней за $0 один раз без карты; месяц $150; год $1500. Платёжные операции относятся к подписке бизнеса, не к заказам посетителей.',['BR09','BR08'])
m.pool('billing','Внешняя платёжная / биллинговая система · провайдер не выбран',blackbox=True)
m.n('s','Открыта подписка бизнеса',0,type='startEvent');m.n('choose','Выбрать пробный период / месяц / год',1);m.n('check','Проверить право управления подпиской',2,1,type='serviceTask');m.n('plan','Выбран пробный период?',3,1,type='exclusiveGateway');m.n('trial','Проверить, не использовано ли пробное право',4,1,type='serviceTask');m.n('used','Пробное право доступно?',5,1,type='exclusiveGateway');m.n('unavailable','Пробный период недоступен; выбрать план',6,track=1);m.n('pay','Создать запрос оплаты выбранного плана',4,1,track=1,type='sendTask');m.n('payment','Получить подтверждённый результат оплаты',5,1,track=1,type='intermediateCatchEvent',message=True);m.n('paid','Оплата подтверждена?',6,1,track=1,type='exclusiveGateway');m.n('failed','Нет активации; показать статус / повтор',7,track=1,type='endEvent');m.n('grant','Идемпотентно активировать 5 прав до end_at',7,1,type='serviceTask');m.n('active','Premium действует до end_at',8,1,type='intermediateCatchEvent',timer='${subscriptionEndAt}',timerKind='timeDate');m.n('renew','Продление подтверждено по согласованным условиям?',9,1,type='exclusiveGateway');m.n('extend','Продлить срок; сохранить единую подписку',10,1,type='serviceTask');m.n('base','Снять истёкшие Premium-права; сохранить данные Venue',10,1,track=1,type='serviceTask');m.n('end','Осталось бесплатное присутствие',11,1,track=1,type='endEvent');m.chain('s','choose','check','plan');m.f('plan','trial','Да');m.chain('trial','used');m.f('used','unavailable','Нет');m.f('unavailable','choose');m.f('used','grant','Да: P7D; без карты и автосписания');m.f('plan','pay','Нет: $150 / $1500');m.f('pay','billing','Запрос оплаты подписки',kind='message');m.chain('pay','payment','paid');m.f('billing','payment','Проверенный результат',kind='message');m.f('paid','failed','Нет / отменено');m.f('paid','grant','Да');m.chain('grant','active','renew');m.f('renew','extend','Да');m.f('extend','active');m.f('renew','base','Нет / срок истёк');m.chain('base','end')

m=model('B10','Premium: ручная погода и приоритет','Пять погодных состояний и подпись до 60 символов. Погода не загружается автоматически; приоритет не обходит права и открытость.',['BR08'])
m.n('s','Открыты настройки карты Premium',0,type='startEvent');m.n('edit','Выбрать погоду; ввести подпись; указать приоритет',1);m.n('check','Проверить право, Premium, 5 состояний и длину',2,1,type='serviceTask');m.n('valid','Данные допустимы?',3,1,type='exclusiveGateway');m.n('save','Сохранить ручную настройку',4,1,type='serviceTask');m.n('open','Venue открыт и доступен для карты?',5,1,type='exclusiveGateway');m.n('show','Погода снизу слева; облако сверху; применить приоритет',6,1,type='serviceTask');m.n('hide','Хранить настройку без показа на живой карте',6,1,track=1,type='serviceTask');m.n('end','Карта соответствует текущим правам',7,1,type='endEvent');m.chain('s','edit','check','valid');m.f('valid','edit','Нет: пояснить ошибку');m.f('valid','save','Да');m.chain('save','open');m.f('open','show','Да');m.f('open','hide','Нет');m.f('show','end');m.f('hide','end')

m=model('B11','Уведомления: согласие, радиус, лимит; аналитика','Правило отправки проверяется для пары Venue/получатель непосредственно перед отправкой. Только измеримые агрегированные действия.',['BR08'])
m.pool('recipient','Обычный пользователь: согласие и уведомление',blackbox=True)
m.n('s','Запрошено уведомление об активности',0,type='startEvent');m.n('context','Выбрать разрешённый контекст / материал',1);m.n('sender','Проверить право отправителя и активный Premium',2,1,type='serviceTask');m.n('eligible','Сформировать кандидатов без раскрытия личного GPS',3,1,type='serviceTask');m.n('guard','Согласие, расстояние ≤1,5 км и лимит ≥90 мин?',4,1,type='exclusiveGateway');m.n('skip','Не отправлять; не расходовать право получателя',5,1,track=1,type='endEvent');m.n('reserve','Атомарно зарезервировать пару Venue/получатель',5,1,type='serviceTask');m.n('send','Отправить разрешённое уведомление',6,1,type='sendTask');m.n('result','Учесть отправку; не предполагать доставку',7,1,type='serviceTask');m.n('aggregate','Обновить агрегаты; не считать визит или выручку',8,1,type='serviceTask');m.n('end','Результат доступен в бизнес-аналитике по правам',9,1,type='endEvent');m.chain('s','context','sender','eligible','guard');m.f('guard','skip','Нет / GPS или согласие неизвестны');m.f('guard','reserve','Да; повторная атомарная проверка');m.chain('reserve','send','result','aggregate','end');m.f('send','recipient','Уведомление с ссылкой на доступный объект',kind='message')
m.n('received','Получено измеримое событие / отзыв согласия',0,1,track=2,type='startEvent',message=True);m.n('verifyEvent','Проверить источник и связь с отправкой',1,1,track=2,type='serviceTask');m.n('eventKind','Отзыв согласия?',2,1,track=2,type='exclusiveGateway');m.n('consent','Обновить согласие для будущих проверок',3,1,track=2,type='serviceTask');m.n('metric','Учесть только подтверждённую доставку/открытие',4,1,track=2,type='serviceTask');m.n('eventEnd','Состояние и агрегаты обновлены',5,1,track=2,type='endEvent');m.chain('received','verifyEvent','eventKind');m.f('eventKind','consent','Да');m.f('eventKind','metric','Нет: доставка / открытие');m.f('consent','eventEnd');m.f('metric','eventEnd');m.f('recipient','received','Подтверждённая доставка, открытие или отзыв',kind='message')

m=model('B12','Права сотрудника и безопасное управление','Названия OWNER/ADMIN/ORGANIZER/MODERATOR/MEMBER не подменяют согласованную матрицу полномочий. Членство само по себе не выдаёт административные права.',['BR06','BR09'])
m.n('s','Сотрудник запрашивает действие',0,type='startEvent');m.n('session','Проверить сессию и принадлежность рабочему пространству',1,1,type='serviceTask');m.n('policy','Проверить capability для объекта и действия',2,1,type='businessRuleTask');m.n('can','Разрешение выдано?',3,1,type='exclusiveGateway');m.n('deny','Отказать без изменения данных и утечки содержимого',4,1,track=1,type='endEvent');m.n('request','Подтвердить целевое изменение',4);m.n('recheck','Перепроверить право и версию объекта при записи',5,1,type='serviceTask');m.n('commit','Сохранить изменение и журнал действия',6,1,type='serviceTask');m.n('invalidate','При смене доступа обновить доступ активных сессий',7,1,type='serviceTask');m.n('end','Изменены только разрешённые данные',8,1,type='endEvent');m.chain('s','session','policy','can');m.f('can','deny','Нет / неизвестная политика');m.f('can','request','Да');m.chain('request','recheck','commit','invalidate','end')

m=model('B13','Полный путь обычного пользователя и ответ бизнеса','Обычный пользователь остаётся в личном приложении. Бизнес-панель, внутренние роли, платежи подписки и служебные чаты ему не показываются.',['BR11','BR16','BR13','BR14','BR10','BR06','BR08'],lanes=('Обычный пользователь · личное приложение',))
m.pools[0]['name']='Обычный пользователь'
m.pool('app','LivCi · публичный API',lanes=('Чтение карточки','Пользовательские действия'))
m.pool('business','Бизнес-кабинет · разрешённые заявки, сообщения и агрегаты',blackbox=True)
m.n('s','Найден Venue / Event / Community',0,type='startEvent');m.n('entry','Открыть с карты, из Community, события или уведомления',1);m.n('req','Запросить карточку',2,type='sendTask');m.n('reply','Получить публичную карточку / ограничение',3,type='receiveTask');m.n('can','Просмотр доступен?',4,type='exclusiveGateway');m.n('no','Увидеть причину недоступности',5,track=2,type='endEvent');m.n('choose','Выбрать раздел или действие',5);m.n('what','Что делает пользователь?',6,type='exclusiveGateway');m.n('read','Сведения, меню, цены, услуги, медиа и публикации',7);m.n('route','Маршрут / публичный телефон / email',7,track=1);m.n('act','Event / вступление / чат / согласие',7,track=2);m.n('sendact','Отправить выбранное действие',8,track=2,type='sendTask');m.n('actionreply','Получить статус, данные или ограничение',9,track=2,type='receiveTask');m.n('e','Результат показан в личном приложении',10,track=1,type='endEvent');m.chain('s','entry','req','reply','can');m.f('can','no','Нет');m.f('can','choose','Да');m.chain('choose','what');m.f('what','read','Прочитать');m.f('what','route','Связаться / маршрут');m.f('what','act','Взаимодействовать');m.f('read','e');m.f('route','e');m.chain('act','sendact','actionreply','e')
m.n('as','Запрос карточки',0,pool='app',type='startEvent',message=True);m.n('filter','Проверить публикацию, доступ и текущую видимость',1,pool='app',type='serviceTask');m.n('project','Собрать публичный вид без админ-данных',2,pool='app',type='serviceTask');m.n('respond','Вернуть данные / явное ограничение',3,pool='app',type='sendTask');m.n('ae','Ответ отправлен',4,pool='app',type='endEvent');m.chain('as','filter','project','respond','ae');m.f('req','as','venue_id + контекст доступа',kind='message');m.f('respond','reply','Публичное представление',kind='message')
m.n('bs','Пользовательское действие',5,lane=1,pool='app',type='startEvent',message=True);m.n('auth','Проверить аутентификацию, объект, членство и правила',6,lane=1,pool='app',type='serviceTask');m.n('authorized','Действие разрешено?',7,lane=1,pool='app',type='exclusiveGateway');m.n('commit','Сохранить результат идемпотентно',8,lane=1,pool='app',type='serviceTask');m.n('rs','Вернуть статус без чужих персональных данных',9,lane=1,pool='app',type='sendTask');m.n('needsBusiness','Создана заявка или сообщение?',10,lane=1,pool='app',type='exclusiveGateway');m.n('notify','Передать в разрешённый раздел кабинета',11,lane=1,pool='app',type='sendTask');m.n('be','Обновить допустимые агрегаты',12,lane=1,pool='app',type='endEvent');m.n('denyAction','Отклонить без изменения данных',8,lane=1,track=1,pool='app',type='serviceTask');m.n('denyResponse','Вернуть причину ограничения',9,lane=1,track=1,pool='app',type='sendTask');m.n('denyEnd','Действие не выполнено',10,lane=1,track=1,pool='app',type='endEvent');m.chain('bs','auth','authorized');m.f('authorized','commit','Да');m.chain('commit','rs','needsBusiness');m.f('needsBusiness','notify','Да');m.f('needsBusiness','be','Нет');m.f('notify','be');m.f('authorized','denyAction','Нет');m.chain('denyAction','denyResponse','denyEnd');m.f('sendact','bs','Выбранное действие и целевой id',kind='message');m.f('rs','actionreply','Результат действия',kind='message');m.f('denyResponse','actionreply','Причина отказа',kind='message');m.f('notify','business','Только разрешённая заявка / сообщение',kind='message')

# Multiple outgoing task flows would mean an implicit parallel split. All choices
# are explicit exclusive gateways; these models never use that accidental fork.
for graph in MODELS:
    for node in list(graph.nodes):
        outgoing=[f for f in graph.edges if f['source']==node['id'] and f.get('kind')!='message']
        if len(outgoing)>1 and not node['type'].endswith('Gateway'):
            pivot=node['id']+'_choice';graph.n(pivot,'',node['col']+.78,lane=node['lane'],track=node['track'],pool=node['pool'],type='exclusiveGateway',compact=True)
            for f in outgoing:
                f['source']=pivot
                if not f['name']:f['name']='Продолжить'
            graph.f(node['id'],pivot)

def write_model(m):
    pref=m.id+'_';qid=lambda x:pref+x
    doc=E.Element('{'+NS['bpmn']+'}definitions',nsmap=NS,id=qid('Definitions'),targetNamespace='https://livci.example/spec/business/2026-10-15',exporter='LivCi business specification',exporterVersion='1.0')
    node_ids={x['id'] for x in m.nodes};pool_ids={p['id'] for p in m.pools};positions={};pool_rect={};lane_rect={};y=60;maxcol=max(n['col'] for n in m.nodes);width=220*(maxcol+1)+120
    for p in m.pools:
        if p['blackbox']:height=95
        else:
            height=0
            for index,lane in enumerate(p['lanes']):
                maxtrack=max((n['track'] for n in m.nodes if n['pool']==p['id'] and n['lane']==index),default=0)
                h=(maxtrack+1)*160+35;lane_rect[(p['id'],index)]=(90,y+height,width-30,h);height+=h
        pool_rect[p['id']]=(60,y,width,height);y+=height+105
    for n in m.nodes:
        lx,ly,lw,lh=lane_rect[(n['pool'],n['lane'])];typ=n['type'];w,h=(38,38) if typ.endswith('Event') or n.get('compact') else (54,54) if typ.endswith('Gateway') else (158,86)
        x=160+n['col']*220;ny=ly+64+n['track']*160
        if typ=='boundaryEvent':
            host=next(x for x in m.nodes if x['id']==n['attached']);x=160+host['col']*220+120;ny=ly+64+host['track']*160+67
        positions[n['id']]=(x,ny,w,h)
    for p in m.pools:
        if p['blackbox']:continue
        process=el(doc,'bpmn:process',id=qid('Process_'+p['id']),isExecutable='false')
        description=el(process,'bpmn:documentation');description.text=m.purpose+' Источники: '+', '.join(m.refs)+'. Рабочая спецификация, не модель исполнения в движке.'
        ls=el(process,'bpmn:laneSet',id=qid('LaneSet_'+p['id']))
        for index,name in enumerate(p['lanes']):
            lane=el(ls,'bpmn:lane',id=qid('Lane_'+p['id']+'_'+str(index)),name=name)
            for n in m.nodes:
                if n['pool']==p['id'] and n['lane']==index:el(lane,'bpmn:flowNodeRef').text=qid(n['id'])
        for n in m.nodes:
            if n['pool']!=p['id']:continue
            attrs={'id':qid(n['id']),'name':n['name']}
            if n['type']=='boundaryEvent':attrs.update(attachedToRef=qid(n['attached']),cancelActivity='true')
            elem=el(process,'bpmn:'+n['type'],**attrs)
            if n.get('called'):
                d=el(elem,'bpmn:documentation');d.text='Детализация: '+n['called']+'.bpmn; внешний документ. calledElement не задан, потому что пакет неисполняемый.'
            for direction,key in [('incoming','target'),('outgoing','source')]:
                for flowIndex,flow in enumerate(m.edges):
                    if flow.get('kind')!='message' and flow[key]==n['id']:el(elem,'bpmn:'+direction).text=qid('Flow_'+str(flowIndex))
            if n.get('timer'):
                td=el(elem,'bpmn:timerEventDefinition',id=qid(n['id']+'_Timer'));t=el(td,'bpmn:'+n.get('timerKind','timeDuration'));t.text=n['timer']
            elif n.get('message'):el(elem,'bpmn:messageEventDefinition',id=qid(n['id']+'_Message'))
        for i,f in enumerate(m.edges):
            if f.get('kind')=='message':continue
            a=next(n for n in m.nodes if n['id']==f['source']);b=next(n for n in m.nodes if n['id']==f['target']);assert a['pool']==b['pool'],(m.id,f)
            if a['pool']!=p['id']:continue
            attrs=dict(id=qid('Flow_'+str(i)),sourceRef=qid(f['source']),targetRef=qid(f['target']))
            if f['name']:attrs['name']=f['name']
            flow=el(process,'bpmn:sequenceFlow',**attrs)
            if f.get('condition'):el(flow,'bpmn:conditionExpression').text=f['condition']
    col=el(doc,'bpmn:collaboration',id=qid('Collaboration'))
    for p in m.pools:
        attrs=dict(id=qid('Participant_'+p['id']),name=p['name'])
        if not p['blackbox']:attrs['processRef']=qid('Process_'+p['id'])
        el(col,'bpmn:participant',**attrs)
    for i,f in enumerate(m.edges):
        if f.get('kind')!='message':continue
        source=qid('Participant_'+f['source']) if f['source'] in pool_ids else qid(f['source']);target=qid('Participant_'+f['target']) if f['target'] in pool_ids else qid(f['target'])
        el(col,'bpmn:messageFlow',id=qid('Flow_'+str(i)),name=f['name'],sourceRef=source,targetRef=target)
    diagram=el(doc,'bpmndi:BPMNDiagram',id=qid('Diagram'),name=m.title);plane=el(diagram,'bpmndi:BPMNPlane',id=qid('Plane'),bpmnElement=qid('Collaboration'))
    def shape(id,rect,**attrs):
        s=el(plane,'bpmndi:BPMNShape',id=qid(id+'_di'),bpmnElement=qid(id),**attrs);x,y,w,h=rect;el(s,'dc:Bounds',x=x,y=y,width=w,height=h);return s
    for p in m.pools:
        shape('Participant_'+p['id'],pool_rect[p['id']],isHorizontal='true')
        if not p['blackbox']:
            for index in range(len(p['lanes'])):shape('Lane_'+p['id']+'_'+str(index),lane_rect[(p['id'],index)],isHorizontal='true')
    for n in m.nodes:
        s=shape(n['id'],positions[n['id']],**({'isExpanded':'false'} if n['type']=='callActivity' else {}))
        if n['name'] and (n['type'].endswith('Event') or n['type'].endswith('Gateway')):
            x,y,w,h=positions[n['id']];label=el(s,'bpmndi:BPMNLabel');el(label,'dc:Bounds',x=x-48,y=y+h+9,width=w+96,height=45)
    def box(id):return pool_rect[id] if id in pool_ids else positions[id]
    for i,f in enumerate(m.edges):
        ax,ay,aw,ah=box(f['source']);bx,by,bw,bh=box(f['target']);sx,sy=ax+aw,ay+ah/2;tx,ty=bx,by+bh/2
        if f.get('kind')=='message':
            sx,sy=ax+aw/2,ay+ah;tx,ty=bx+bw/2,by
            if sy>ty:sx,sy=ax+aw/2,ay;tx,ty=bx+bw/2,by+bh
            mid=(sy+ty)/2;points=[(sx,sy),(sx,mid),(tx,mid),(tx,ty)]
        elif abs(ay-by)<4 and bx>ax:points=[(sx,sy),(tx,ty)]
        elif abs(ax-bx)<4:
            sx=ax+aw/2;tx=bx+bw/2
            if by>ay:sy=ay+ah;ty=by
            else:sy=ay;ty=by+bh
            mid=(sy+ty)/2;points=[(sx,sy),(sx,mid),(tx,mid),(tx,ty)]
        elif bx<ax:
            sx,sy=ax+aw/2,ay;tx,ty=bx+bw/2,by;routeY=min(ay,by)-27;points=[(sx,sy),(sx,routeY),(tx,routeY),(tx,ty)]
        else:
            middle=(sx+tx)/2;points=[(sx,sy),(middle,sy),(middle,ty),(tx,ty)]
        # Route around task/event boxes rather than drawing through an intermediate activity.
        def obstructed(path):
            for (x1,y1),(x2,y2) in zip(path,path[1:]):
                for rx,ry,rw,rh in positions.values():
                    if abs(y2-y1)<.1 and ry+1<y1<ry+rh-1 and min(max(x1,x2),rx+rw-1)>max(min(x1,x2),rx+1):return True
                    if abs(x2-x1)<.1 and rx+1<x1<rx+rw-1 and min(max(y1,y2),ry+rh-1)>max(min(y1,y2),ry+1):return True
            return False
        if obstructed(points):
            candidates=[]
            for xs in [ax+aw+5,ax+aw+25,ax-5,ax-25]:
                for xt in [bx-5,bx-25,bx+bw+5,bx+bw+25]:
                    for band in [min(ay,by)-24,max(ay+ah,by+bh)+24,min(r[1] for r in positions.values())-35]:
                        startX=ax+aw if xs>ax else ax;endX=bx if xt<bx else bx+bw
                        path=[(startX,ay+ah/2),(xs,ay+ah/2),(xs,band),(xt,band),(xt,by+bh/2),(endX,by+bh/2)]
                        if not obstructed(path):candidates.append((sum(abs(a[0]-b[0])+abs(a[1]-b[1]) for a,b in zip(path,path[1:])),path))
            if candidates:points=min(candidates,key=lambda p:p[0])[1]
        edge=el(plane,'bpmndi:BPMNEdge',id=qid('Flow_'+str(i)+'_di'),bpmnElement=qid('Flow_'+str(i)))
        clean=[]
        for point in points:
            if not clean or clean[-1]!=point:clean.append(point)
        for x,y in clean:el(edge,'di:waypoint',x=x,y=y)
        if f['name']:
            start=clean[max(0,len(clean)//2-1)];end=clean[len(clean)//2];cx=(start[0]+end[0])/2;cy=(start[1]+end[1])/2
            lab=el(edge,'bpmndi:BPMNLabel');el(lab,'dc:Bounds',x=cx-75,y=cy-27,width=150,height=36)
    target=ROOT/'models'/f'{m.id}.bpmn';target.parent.mkdir(exist_ok=True);E.ElementTree(doc).write(target,encoding='UTF-8',xml_declaration=True,pretty_print=True)
    return dict(id=m.id,title=m.title,purpose=m.purpose,references=m.refs,file='models/'+target.name,nodes=len(m.nodes),flows=len(m.edges),pools=len(m.pools))

if __name__=='__main__':
    manifest=[write_model(m) for m in MODELS]
    (ROOT/'model-index.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2))
    master=E.Element('{'+NS['bpmn']+'}definitions',nsmap=NS,id='LivCiBusiness_Definitions',targetNamespace='urn:livci:business:2026-10-15',exporter='LivCi business specification',exporterVersion='1.0')
    diagrams=[]
    for entry in manifest:
        tree=E.parse(str(ROOT/entry['file']))
        for child in list(tree.getroot()):
            if E.QName(child).localname=='BPMNDiagram':diagrams.append(child)
            else:master.append(child)
    for diagram in diagrams:master.append(diagram)
    for activity in master.findall('.//{'+NS['bpmn']+'}callActivity'):
        for d in activity.findall('{'+NS['bpmn']+'}documentation'):
            if d.text and d.text.startswith('Детализация: '):
                target=d.text.split('Детализация: ',1)[1].split('.bpmn',1)[0]
                activity.set('calledElement',target+'_Process_main')
    E.ElementTree(master).write(ROOT/'LivCi_Business.bpmn',encoding='UTF-8',xml_declaration=True,pretty_print=True)
    print(json.dumps({'models':len(manifest),'nodes':sum(x['nodes'] for x in manifest),'flows':sum(x['flows'] for x in manifest)},ensure_ascii=False))
